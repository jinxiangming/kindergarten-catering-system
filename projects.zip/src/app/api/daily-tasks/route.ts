import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    message: 'Daily tasks are fetched client-side via Supabase SDK',
  });
}
