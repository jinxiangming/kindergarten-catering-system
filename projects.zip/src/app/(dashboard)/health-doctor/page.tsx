'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  Card, Button, Upload, Table, Tag, Modal, message, Tabs, Space,
  Descriptions, Timeline, Empty, Spin, DatePicker, Input,
} from 'antd';
import {
  UploadOutlined, DownloadOutlined, CheckCircleOutlined,
  EditOutlined, SaveOutlined, SendOutlined, StopOutlined, DeleteOutlined,
} from '@ant-design/icons';
import { useAuth } from '@/contexts/AuthContext';
import { getBrowserClient } from '@/lib/supabase';
import {
  RECIPE_STATUS_LABELS, MEAL_TYPE_LABELS, MEAL_TYPE_ORDER,
  type Recipe, type RecipeDetail, type ApprovalRecord, type MealType,
} from '@/types';
import dayjs from 'dayjs';
import * as XLSX from 'xlsx';

const { RangePicker } = DatePicker;

export default function HealthDoctorPage() {
  const { user, profile } = useAuth();
  const supabase = getBrowserClient();
  const [activeTab, setActiveTab] = useState('todo');
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [historyRecipes, setHistoryRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);
  const [detailsModalOpen, setDetailsModalOpen] = useState(false);
  const [selectedRecipe, setSelectedRecipe] = useState<Recipe | null>(null);
  const [recipeDetails, setRecipeDetails] = useState<RecipeDetail[]>([]);
  const [approvalRecords, setApprovalRecords] = useState<ApprovalRecord[]>([]);
  const [parsedData, setParsedData] = useState<RecipeDetail[]>([]);
  const [uploadWeekStart, setUploadWeekStart] = useState<string>(dayjs().startOf('week').add(1, 'day').format('YYYY-MM-DD'));
  const [editRecipeId, setEditRecipeId] = useState<string | null>(null);
  const [savedRecipeId, setSavedRecipeId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const fetchRecipes = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('recipes')
        .select('*, profiles:uploader_id(display_name, email)')
        .eq('uploader_id', user.id)
        .order('created_at', { ascending: false });
      if (error) {
        message.error('获取食谱列表失败：' + error.message);
      } else {
        const all = (data || []) as unknown as Recipe[];
        setRecipes(all.filter(r =>
          r.status === 'rejected_kitchen' ||
          r.status === 'rejected_finance' ||
          r.status === 'rejected_principal' ||
          r.status === 'draft'
        ));
        setHistoryRecipes(all);
      }
    } catch (err) {
      message.error('获取食谱列表失败');
    }
    setLoading(false);
  }, [user, supabase]);

  useEffect(() => { fetchRecipes(); }, [fetchRecipes]);

  const fetchDetails = async (recipe: Recipe) => {
    setSelectedRecipe(recipe);
    const { data: details } = await supabase
      .from('recipe_details')
      .select('*')
      .eq('recipe_id', recipe.id)
      .order('date')
      .order('meal_type');
    setRecipeDetails((details || []) as RecipeDetail[]);

    const { data: records } = await supabase
      .from('approval_records')
      .select('*, profiles:approver_id(display_name, email)')
      .eq('recipe_id', recipe.id)
      .order('created_at');
    setApprovalRecords((records || []) as unknown as ApprovalRecord[]);
    setDetailsModalOpen(true);
  };

  const downloadTemplate = () => {
    const wb = XLSX.utils.book_new();

    // === 使用说明 Sheet ===
    const instructionData = [
      ['幼儿园周食谱上传模板 - 使用说明'],
      [''],
      ['1. 请在"食谱录入"页签中填写本周食谱数据'],
      ['2. 日期格式：YYYY-MM-DD，例如 2025-01-06'],
      ['3. 餐别可选值：元气早餐、能量加餐、营养中餐、均衡午点'],
      ['4. 同一天同一餐别下可填写多道菜品，每道菜品一行'],
      ['5. 食材与带量：请将所有食材和用量写在同一格，例如"小米15克 红薯5克 盐1克 油6克"'],
      ['6. 日期列只需在当天第一行填写，后续行如日期相同可留空（自动沿用）'],
      ['7. 所有字段均为必填（备注除外）'],
      [''],
      ['参考示例：'],
      ['日期', '餐别', '菜品名称', '食材与带量', '备注'],
      ['2025-01-06', '元气早餐', '小米红薯粥', '小米15克 红薯5克 盐1克 油6克', ''],
      ['', '', '木耳肉末炒白菜', '白菜50克 猪肉10克 木耳适量', ''],
      ['', '', '西葫芦鸡蛋饼', '鸡蛋20克 西葫芦适量 面粉30克', ''],
      ['2025-01-06', '能量加餐', '香蕉', '香蕉110克', ''],
      ['2025-01-06', '营养中餐', '老北京炸酱面', '面粉70克 青菜30克 猪肉40克 鸡蛋30克 油8克 盐1克', ''],
      ['', '', '芝麻千层饼', '芝麻适量 面粉20克', ''],
      ['2025-01-06', '均衡午点', '砂糖橘', '砂糖橘50克', ''],
      ['', '', '牛奶蒸玉米', '牛奶125克 玉米30克', ''],
    ];
    const wsInstruction = XLSX.utils.aoa_to_sheet(instructionData);
    wsInstruction['!cols'] = [{ wch: 14 }, { wch: 12 }, { wch: 20 }, { wch: 50 }, { wch: 16 }];
    XLSX.utils.book_append_sheet(wb, wsInstruction, '使用说明');

    // === 食谱录入 Sheet（空白模板，含表头） ===
    const weekStart = dayjs().startOf('week').add(1, 'day'); // 本周一
    const weekDays = ['一', '二', '三', '四', '五'];
    const mealTypes = ['元气早餐', '能量加餐', '营养中餐', '均衡午点'];

    const templateData: string[][] = [['日期', '餐别', '菜品名称', '食材与带量', '备注']];

    // 预填一周的日期和餐别框架
    weekDays.forEach((dayName, dayIdx) => {
      const date = weekStart.add(dayIdx, 'day').format('YYYY-MM-DD');
      mealTypes.forEach((meal) => {
        templateData.push([date, meal, '', '', '']);
        templateData.push(['', '', '', '', '']); // 第二行留空供多道菜
      });
    });

    const wsTemplate = XLSX.utils.aoa_to_sheet(templateData);
    wsTemplate['!cols'] = [{ wch: 14 }, { wch: 12 }, { wch: 20 }, { wch: 50 }, { wch: 16 }];
    XLSX.utils.book_append_sheet(wb, wsTemplate, '食谱录入');

    XLSX.writeFile(wb, '幼儿园食谱模板.xlsx');
    message.success('模板已下载');
  };

  // Excel 日期序列号转日期字符串
  const excelSerialToDate = (serial: number): string => {
    // Excel 日期序列号：1 = 1900-01-01，但 Excel 有闰年 bug（1900-02-29 不存在但被计算了）
    // 所以序列号 >= 60 时需要减1
    const adjustedSerial = serial > 59 ? serial - 1 : serial;
    const epoch = new Date(1899, 11, 31); // 1899-12-31
    const date = new Date(epoch.getTime() + adjustedSerial * 86400000);
    return dayjs(date).format('YYYY-MM-DD');
  };

  // 尝试解析日期字符串（支持多种格式）
  const parseDateString = (dateStr: string): string | null => {
    // 尝试 YYYY-MM-DD
    if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(dateStr)) {
      const d = dayjs(dateStr, 'YYYY-MM-DD');
      if (d.isValid()) return d.format('YYYY-MM-DD');
    }
    // 尝试 YYYY/MM/DD
    if (/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(dateStr)) {
      const d = dayjs(dateStr, 'YYYY/MM/DD');
      if (d.isValid()) return d.format('YYYY-MM-DD');
    }
    // 尝试 YYYY年MM月DD日
    const cnMatch = dateStr.match(/^(\d{4})年(\d{1,2})月(\d{1,2})日$/);
    if (cnMatch) {
      const d = dayjs(`${cnMatch[1]}-${cnMatch[2]}-${cnMatch[3]}`, 'YYYY-M-D');
      if (d.isValid()) return d.format('YYYY-MM-DD');
    }
    // dayjs 通用解析
    const d = dayjs(dateStr);
    if (d.isValid() && d.year() > 2000) return d.format('YYYY-MM-DD');
    return null;
  };

  const parseExcel = (file: File) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });
        // 优先使用"食谱录入"页签，其次使用第一个非"使用说明"页签
        const targetSheetName = workbook.SheetNames.find(n => n.includes('食谱')) || workbook.SheetNames.find(n => !n.includes('说明')) || workbook.SheetNames[0];
        const sheet = workbook.Sheets[targetSheetName];
        // 使用 raw:false + dateNF 让 xlsx 自动格式化日期
        const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, {
          raw: false,
          dateNF: 'YYYY-MM-DD',
        });

        if (rows.length === 0) {
          message.error('Excel 文件为空');
          return;
        }

        const mealTypeMap: Record<string, MealType> = {
          '元气早餐': 'breakfast', '早餐': 'breakfast',
          '能量加餐': 'morning_snack', '早点': 'morning_snack', '加餐': 'morning_snack',
          '营养中餐': 'lunch', '午餐': 'lunch', '中餐': 'lunch',
          '均衡午点': 'afternoon_snack', '午点': 'afternoon_snack',
        };

        const errors: string[] = [];
        const parsed: RecipeDetail[] = [];
        let lastDate: string | null = null; // 沿用上一个日期

        rows.forEach((row, idx) => {
          const rowNum = idx + 2;
          const dateRaw = row['日期'];
          const mealTypeStr = String(row['餐别'] || '').trim();
          const dishName = String(row['菜品名称'] || row['菜品'] || '').trim();
          const ingredientStr = String(row['食材与带量'] || row['食材'] || '').trim();
          const remark = String(row['备注'] || '').trim();

          // 跳过完全空行
          if (!dateRaw && !mealTypeStr && !dishName && !ingredientStr) return;

          if (!dishName && !ingredientStr) return; // 无有效数据的行跳过

          if (!dishName) {
            errors.push(`第${rowNum}行：菜品名称为必填`);
            return;
          }
          if (!ingredientStr) {
            errors.push(`第${rowNum}行：食材与带量为必填`);
            return;
          }

          // 解析日期：可能是字符串，也可能是 Excel 序列号（数字）
          let date: string | null = null;
          if (dateRaw !== undefined && dateRaw !== null && dateRaw !== '') {
            if (typeof dateRaw === 'number') {
              date = excelSerialToDate(dateRaw);
            } else {
              const dateStr = String(dateRaw).trim();
              if (dateStr) date = parseDateString(dateStr);
            }
            if (date) lastDate = date; // 更新沿用日期
          }

          // 日期沿用上一行
          if (!date) date = lastDate;

          if (!date) {
            errors.push(`第${rowNum}行：日期为必填且格式不正确`);
            return;
          }

          // 餐别沿用上一行（如果没有填）
          const finalMealTypeStr = mealTypeStr || '';
          const mealType = mealTypeMap[finalMealTypeStr];
          if (finalMealTypeStr && !mealType) {
            errors.push(`第${rowNum}行：餐别不正确（${finalMealTypeStr}），可选：元气早餐/能量加餐/营养中餐/均衡午点`);
            return;
          }
          if (!mealType) {
            errors.push(`第${rowNum}行：餐别为必填`);
            return;
          }

          // 食材与带量直接作为 ingredient 字段存储（如"小米15克 红薯5克 盐1克"）
          // amount 设为 0 表示综合用量，不再拆分
          parsed.push({
            id: `temp-${Date.now()}-${idx}`,
            recipe_id: '',
            date,
            meal_type: mealType,
            dish_name: dishName,
            ingredient: ingredientStr,
            amount: 0,
            remark: remark || null,
            created_at: new Date().toISOString(),
          });
        });

        if (errors.length > 0) {
          Modal.error({
            title: 'Excel 数据校验失败',
            content: (
              <div style={{ maxHeight: 300, overflow: 'auto' }}>
                {errors.map((err, i) => <div key={i}>{err}</div>)}
              </div>
            ),
          });
          return;
        }

        setParsedData(parsed);
        setSavedRecipeId(null); // 新解析的数据，需要重新上传
        message.success(`解析成功，共 ${parsed.length} 条菜品记录`);
      } catch (err) {
        message.error('解析 Excel 失败：' + (err instanceof Error ? err.message : '未知错误'));
      }
    };
    reader.readAsArrayBuffer(file);
  };

  // 上传保存（草稿状态）
  const saveRecipe = async () => {
    if (!user || parsedData.length === 0) return;
    setSaving(true);
    try {
      let recipeId = editRecipeId;

      if (editRecipeId) {
        // 修改已有食谱：删除旧的明细，更新状态为草稿
        const { error: delError } = await supabase.from('recipe_details').delete().eq('recipe_id', editRecipeId);
        if (delError) throw new Error('删除旧数据失败：' + delError.message);

        const { error: updateError } = await supabase.from('recipes').update({
          status: 'draft',
          reject_reason: null,
          reject_step: null,
          week_start_date: uploadWeekStart,
          updated_at: new Date().toISOString(),
        }).eq('id', editRecipeId);
        if (updateError) throw new Error('更新食谱失败：' + updateError.message);
      } else {
        // 新建食谱
        const { data: newRecipe, error: recipeError } = await supabase
          .from('recipes')
          .insert({
            uploader_id: user.id,
            week_start_date: uploadWeekStart,
            status: 'draft',
          })
          .select()
          .single();
        if (recipeError) throw new Error('创建食谱失败：' + recipeError.message);
        recipeId = (newRecipe as Recipe).id;
      }

      // 插入明细
      const details = parsedData.map(d => ({
        recipe_id: recipeId,
        date: d.date,
        meal_type: d.meal_type,
        dish_name: d.dish_name,
        ingredient: d.ingredient,
        amount: d.amount,
        remark: d.remark,
      }));
      const { error: detailError } = await supabase.from('recipe_details').insert(details);
      if (detailError) throw new Error('保存明细失败：' + detailError.message);

      setSavedRecipeId(recipeId);
      message.success('食谱已上传保存（草稿状态）');
      fetchRecipes();
    } catch (err) {
      message.error('上传失败：' + (err instanceof Error ? err.message : '未知错误'));
    }
    setSaving(false);
  };

  // 提交审核
  const submitForReview = async () => {
    if (!user) return;

    // 如果还没有上传保存，先保存
    let recipeId = savedRecipeId || editRecipeId;
    if (!recipeId) {
      message.warning('请先上传食谱');
      return;
    }

    setSubmitting(true);
    try {
      const { error } = await supabase.from('recipes').update({
        status: 'pending_kitchen',
        updated_at: new Date().toISOString(),
      }).eq('id', recipeId);
      if (error) throw new Error(error.message);

      setParsedData([]);
      setSavedRecipeId(null);
      setEditRecipeId(null);
      message.success('食谱已提交审核');
      fetchRecipes();
    } catch (err) {
      message.error('提交审核失败：' + (err instanceof Error ? err.message : '未知错误'));
    }
    setSubmitting(false);
  };

  const handleEditRecipe = (recipe: Recipe) => {
    setEditRecipeId(recipe.id);
    setUploadWeekStart(recipe.week_start_date);
    // Load existing details for re-editing
    supabase.from('recipe_details').select('*').eq('recipe_id', recipe.id)
      .then(({ data }) => {
        if (data) setParsedData(data as RecipeDetail[]);
      });
    setActiveTab('upload');
  };

  const handleVoidRecipe = async (recipe: Recipe) => {
    Modal.confirm({
      title: '确认作废',
      content: `确定要作废该食谱吗？作废后该食谱不再流转，但仍可查看详情。`,
      okText: '确认作废',
      okType: 'danger',
      cancelText: '取消',
      onOk: async () => {
        try {
          const { error } = await supabase.from('recipes').update({
            status: 'voided',
            updated_at: new Date().toISOString(),
          }).eq('id', recipe.id);
          if (error) throw new Error(error.message);
          message.success('食谱已作废');
          fetchRecipes();
        } catch (err) {
          message.error('作废失败：' + (err instanceof Error ? err.message : '未知错误'));
        }
      },
    });
  };

  const handleDeleteRecipe = async (recipe: Recipe) => {
    Modal.confirm({
      title: '确认删除',
      content: `确定要彻底删除该食谱吗？删除后数据将无法恢复！`,
      okText: '确认删除',
      okType: 'danger',
      cancelText: '取消',
      onOk: async () => {
        try {
          // 先删除明细
          const { error: detailError } = await supabase.from('recipe_details').delete().eq('recipe_id', recipe.id);
          if (detailError) throw new Error('删除明细失败：' + detailError.message);
          // 再删除审批记录
          await supabase.from('approval_records').delete().eq('recipe_id', recipe.id);
          // 最后删除食谱
          const { error: recipeError } = await supabase.from('recipes').delete().eq('id', recipe.id);
          if (recipeError) throw new Error('删除食谱失败：' + recipeError.message);
          message.success('食谱已彻底删除');
          fetchRecipes();
        } catch (err) {
          message.error('删除失败：' + (err instanceof Error ? err.message : '未知错误'));
        }
      },
    });
  };

  const columns = [
    {
      title: '周开始日期',
      dataIndex: 'week_start_date',
      key: 'week_start_date',
      render: (date: string) => dayjs(date).format('YYYY-MM-DD'),
    },
    {
      title: '状态',
      dataIndex: 'status',
      key: 'status',
      render: (status: string) => {
        const colorMap: Record<string, string> = {
          draft: 'default', pending_kitchen: 'processing', pending_finance: 'processing',
          pending_principal: 'processing', approved: 'success', effective: 'success',
          rejected_kitchen: 'error', rejected_finance: 'error', rejected_principal: 'error',
        };
        return <Tag color={colorMap[status] || 'default'}>{RECIPE_STATUS_LABELS[status as keyof typeof RECIPE_STATUS_LABELS] || status}</Tag>;
      },
    },
    {
      title: '退回原因',
      dataIndex: 'reject_reason',
      key: 'reject_reason',
      render: (text: string | null) => text || '-',
    },
    {
      title: '提交时间',
      dataIndex: 'created_at',
      key: 'created_at',
      render: (date: string) => dayjs(date).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: '操作',
      key: 'action',
      render: (_: unknown, record: Recipe) => (
        <Space>
          <Button size="small" onClick={() => fetchDetails(record)}>查看详情</Button>
          {['rejected_kitchen', 'rejected_finance', 'rejected_principal', 'draft'].includes(record.status) && (
            <Button size="small" type="primary" icon={<EditOutlined />} onClick={() => handleEditRecipe(record)}>
              修改重提
            </Button>
          )}
          {['rejected_kitchen', 'rejected_finance', 'rejected_principal', 'draft'].includes(record.status) && (
            <Button size="small" danger icon={<StopOutlined />} onClick={() => handleVoidRecipe(record)}>
              作废
            </Button>
          )}
          {['rejected_kitchen', 'rejected_finance', 'rejected_principal', 'draft'].includes(record.status) && (
            <Button size="small" danger icon={<DeleteOutlined />} onClick={() => handleDeleteRecipe(record)}>
              删除
            </Button>
          )}
        </Space>
      ),
    },
  ];

  const detailColumns = [
    { title: '日期', dataIndex: 'date', key: 'date', render: (d: string) => dayjs(d).format('MM-DD') },
    { title: '餐别', dataIndex: 'meal_type', key: 'meal_type', render: (t: MealType) => MEAL_TYPE_LABELS[t] },
    { title: '菜品名称', dataIndex: 'dish_name', key: 'dish_name' },
    { title: '食材与带量', dataIndex: 'ingredient', key: 'ingredient' },
    { title: '备注', dataIndex: 'remark', key: 'remark', render: (t: string | null) => t || '-' },
  ];

  const renderApprovalTimeline = () => (
    <Timeline
      items={approvalRecords.map((r) => ({
        color: r.result === 'approved' ? 'green' : 'red',
        content: (
          <div>
            <strong>{r.step === 'kitchen' ? '厨房审核' : r.step === 'finance' ? '财务审核' : '园长终审'}</strong>
            <Tag color={r.result === 'approved' ? 'success' : 'error'} style={{ marginLeft: 8 }}>
              {r.result === 'approved' ? '通过' : '退回'}
            </Tag>
            {r.profiles && <div style={{ color: '#888' }}>审核人：{(r.profiles as { display_name: string }).display_name}</div>}
            {r.comment && <div style={{ color: '#666' }}>意见：{r.comment}</div>}
            <div style={{ color: '#aaa', fontSize: 12 }}>{dayjs(r.created_at).format('YYYY-MM-DD HH:mm')}</div>
          </div>
        ),
      }))}
    />
  );

  const renderParsedPreview = () => {
    if (parsedData.length === 0) return <Empty description="请上传 Excel 文件预览数据" />;

    // Group by date and meal_type
    const grouped: Record<string, Record<string, RecipeDetail[]>> = {};
    parsedData.forEach(d => {
      if (!grouped[d.date]) grouped[d.date] = {};
      if (!grouped[d.date][d.meal_type]) grouped[d.date][d.meal_type] = [];
      grouped[d.date][d.meal_type].push(d);
    });

    return (
      <div>
        <div style={{ marginBottom: 16 }}>
          <Tag color="green">共 {parsedData.length} 条食材记录</Tag>
          <Tag>{Object.keys(grouped).length} 天</Tag>
        </div>
        {Object.entries(grouped).sort().map(([date, meals]) => (
          <Card key={date} size="small" title={dayjs(date).format('YYYY年MM月DD日')} style={{ marginBottom: 8 }}>
            {MEAL_TYPE_ORDER.map(mt => meals[mt] && (
              <div key={mt} style={{ marginBottom: 4 }}>
                <Tag color="blue">{MEAL_TYPE_LABELS[mt]}</Tag>
                {meals[mt].map((d, i) => (
                  <span key={i} style={{ marginRight: 12 }}>
                    {d.dish_name}（{d.ingredient}）
                  </span>
                ))}
              </div>
            ))}
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div>
      <h2 style={{ marginBottom: 24 }}>保健医工作台</h2>
      <Tabs activeKey={activeTab} onChange={setActiveTab} items={[
        {
          key: 'upload',
          label: '上传食谱',
          children: (
            <Space orientation="vertical" size="large" style={{ width: '100%' }}>
              <Card title="食谱模板">
                <Space>
                  <Button icon={<DownloadOutlined />} onClick={downloadTemplate}>下载标准模板</Button>
                  <span style={{ color: '#888' }}>模板字段：日期、餐别、菜品名称、食材与带量、备注</span>
                </Space>
              </Card>
              <Card title="上传食谱文件">
                <Space orientation="vertical" style={{ width: '100%' }}>
                  <Space wrap>
                    <span>周开始日期：</span>
                    <DatePicker
                      value={dayjs(uploadWeekStart)}
                      onChange={(_, ds) => setUploadWeekStart(String(ds))}
                      allowClear={false}
                    />
                    <Upload
                      accept=".xlsx,.xls"
                      showUploadList={false}
                      beforeUpload={(file) => { parseExcel(file); return false; }}
                    >
                      <Button icon={<UploadOutlined />}>选择 Excel 文件</Button>
                    </Upload>
                  </Space>
                  {parsedData.length > 0 && (
                    <Space wrap style={{ marginTop: 8 }}>
                      <Button
                        icon={<SaveOutlined />}
                        onClick={saveRecipe}
                        loading={saving}
                      >
                        {savedRecipeId || editRecipeId ? '重新上传' : '上传'}
                      </Button>
                      <Button
                        type="primary"
                        icon={<SendOutlined />}
                        onClick={submitForReview}
                        loading={submitting}
                        disabled={!savedRecipeId && !editRecipeId}
                      >
                        提交审核
                      </Button>
                      {editRecipeId && (
                        <Button onClick={() => { setEditRecipeId(null); setParsedData([]); setSavedRecipeId(null); }}>取消编辑</Button>
                      )}
                    </Space>
                  )}
                  {(!savedRecipeId && !editRecipeId) && parsedData.length > 0 && (
                    <div style={{ color: '#faad14', fontSize: 13 }}>请先点击"上传"保存食谱，再点击"提交审核"</div>
                  )}
                  {renderParsedPreview()}
                </Space>
              </Card>
            </Space>
          ),
        },
        {
          key: 'todo',
          label: <span>待办事项{recipes.length > 0 && <Tag color="red" style={{ marginLeft: 4 }}>{recipes.length}</Tag>}</span>,
          children: (
            <Card>
              <Table
                columns={columns}
                dataSource={recipes}
                rowKey="id"
                loading={loading}
                locale={{ emptyText: <Empty description="暂无待办事项" /> }}
              />
            </Card>
          ),
        },
        {
          key: 'history',
          label: '历史记录',
          children: (
            <Card>
              <Table
                columns={columns}
                dataSource={historyRecipes}
                rowKey="id"
                loading={loading}
              />
            </Card>
          ),
        },
      ]} />

      <Modal
        title="食谱详情"
        open={detailsModalOpen}
        onCancel={() => setDetailsModalOpen(false)}
        footer={null}
        width={900}
      >
        {selectedRecipe && (
          <div>
            <Descriptions bordered size="small" column={2} style={{ marginBottom: 16 }}>
              <Descriptions.Item label="周开始日期">{dayjs(selectedRecipe.week_start_date).format('YYYY-MM-DD')}</Descriptions.Item>
              <Descriptions.Item label="状态">
                <Tag color={selectedRecipe.status.includes('reject') ? 'error' : 'processing'}>
                  {RECIPE_STATUS_LABELS[selectedRecipe.status as keyof typeof RECIPE_STATUS_LABELS]}
                </Tag>
              </Descriptions.Item>
              {selectedRecipe.reject_reason && (
                <Descriptions.Item label="退回原因" span={2}>
                  <span style={{ color: '#ff4d4f' }}>{selectedRecipe.reject_reason}</span>
                </Descriptions.Item>
              )}
            </Descriptions>
            <Tabs items={[
              { key: 'details', label: '食谱明细', children: <Table columns={detailColumns} dataSource={recipeDetails} rowKey="id" size="small" pagination={false} /> },
              { key: 'approval', label: '审核记录', children: approvalRecords.length > 0 ? renderApprovalTimeline() : <Empty description="暂无审核记录" /> },
            ]} />
          </div>
        )}
      </Modal>
    </div>
  );
}
