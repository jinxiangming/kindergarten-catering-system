import { NextResponse } from 'next/server';

export async function GET() {
  // Return the template structure info
  // The actual Excel template is generated client-side via xlsx library
  return NextResponse.json({
    message: 'Template should be downloaded from the health-doctor workstation',
    fields: ['日期', '餐别', '菜品名称', '食材与带量', '备注'],
    meal_types: ['元气早餐', '能量加餐', '营养中餐', '均衡午点'],
  });
}
