import { NextRequest, NextResponse } from 'next/server';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  try {
    const body = await request.json();
    const { approver_id, step, result, comment } = body;

    if (!approver_id || !step || !result) {
      return NextResponse.json({ error: '缺少必填字段' }, { status: 400 });
    }

    return NextResponse.json({
      message: 'Approval is handled client-side via Supabase SDK',
      recipe_id: id,
      approval: { step, result, comment },
    });
  } catch {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
}
