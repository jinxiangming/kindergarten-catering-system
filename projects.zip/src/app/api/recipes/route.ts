import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const status = searchParams.get('status');
  const uploader_id = searchParams.get('uploader_id');

  // This API route serves as documentation for the Supabase query patterns
  // Actual data fetching is done client-side for real-time auth context
  return NextResponse.json({
    message: 'Recipes are fetched client-side via Supabase SDK',
    filters: { status, uploader_id },
    status_options: [
      'draft', 'pending_kitchen', 'pending_finance', 'pending_principal',
      'approved', 'rejected_kitchen', 'rejected_finance', 'rejected_principal', 'effective'
    ],
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { uploader_id, week_start_date, details } = body;

    if (!uploader_id || !week_start_date || !details?.length) {
      return NextResponse.json({ error: '缺少必填字段' }, { status: 400 });
    }

    return NextResponse.json({
      message: 'Recipe creation is handled client-side via Supabase SDK',
    });
  } catch {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
}
