import AuthGuardWrapper from '@/components/AuthGuard';
import DashboardLayout from '@/components/dashboard/DashboardLayout';

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <AuthGuardWrapper>
      <DashboardLayout>{children}</DashboardLayout>
    </AuthGuardWrapper>
  );
}
