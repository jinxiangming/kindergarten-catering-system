'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  Card, Table, Tag, Button, Modal, Space, Tabs, Empty, message,
  Descriptions, Form, Input, Select, Timeline, List,
} from 'antd';
import {
  CheckCircleOutlined, CloseCircleOutlined, EyeOutlined,
  ShoppingCartOutlined,
} from '@ant-design/icons';
import { useAuth } from '@/contexts/AuthContext';
import { getBrowserClient } from '@/lib/supabase';
import {
  RECIPE_STATUS_LABELS, MEAL_TYPE_LABELS,
  type Recipe, type RecipeDetail, type ApprovalRecord, type PurchaseOrder,
} from '@/types';
import dayjs from 'dayjs';
import isoWeek from 'dayjs/plugin/isoWeek';

dayjs.extend(isoWeek);

// Extract clean ingredient names from a raw ingredient string
// e.g. "面粉70克 青菜30克 猪肉40克 鸡蛋30克 油8克 盐适量" → ["面粉","青菜","猪肉","鸡蛋","油","盐"]
function extractCleanIngredientNames(ingredientStr: string): string[] {
  if (!ingredientStr) return [];
  const names: string[] = [];
  // Global match: Chinese chars + optional number + unit(g/克) or "适量/少许/若干"
  const regex = /([^\d\s、,;；]+?)(?:\d+(?:\.\d+)?\s*(?:g|克)|适量|少许|若干)/g;
  let match;
  while ((match = regex.exec(ingredientStr)) !== null) {
    const name = match[1].trim();
    if (name) names.push(name);
  }
  return names;
}

// Parse ingredient string into name + amount (for DB storage)
function parseIngredientWithAmount(ingredientStr: string): { name: string; amount: number }[] {
  if (!ingredientStr) return [];
  const result: { name: string; amount: number }[] = [];
  // Match: name + number + unit(g/克)
  const regex = /([^\d\s、,;；]+?)(\d+(?:\.\d+)?)\s*(g|克)/g;
  let match;
  while ((match = regex.exec(ingredientStr)) !== null) {
    result.push({ name: match[1].trim(), amount: parseFloat(match[2]) });
  }
  // Also match "适量/少许/若干" entries (amount = 0)
  const qualRegex = /([^\d\s、,;；]+?)(适量|少许|若干)/g;
  while ((match = qualRegex.exec(ingredientStr)) !== null) {
    const name = match[1].trim();
    if (name && !result.some(r => r.name === name)) {
      result.push({ name, amount: 0 });
    }
  }
  return result;
}

// Get unique ingredient names from recipe details (for UI display - clean names only)
function getIngredientNames(details: RecipeDetail[]): { name: string }[] {
  const names = new Set<string>();
  for (const d of details) {
    const extracted = extractCleanIngredientNames(d.ingredient || '');
    for (const name of extracted) {
      if (name) names.add(name);
    }
  }
  return Array.from(names)
    .sort((a, b) => a.localeCompare(b, 'zh-CN'))
    .map(name => ({ name }));
}

// Aggregate all ingredients from recipe details (for DB storage)
function aggregateIngredients(details: RecipeDetail[]): { name: string; total_amount: number; unit: string }[] {
  const agg: Record<string, { total: number; unit: string }> = {};
  for (const d of details) {
    const parsed = parseIngredientWithAmount(d.ingredient || '');
    for (const item of parsed) {
      if (!agg[item.name]) {
        agg[item.name] = { total: 0, unit: '克' };
      }
      agg[item.name].total += item.amount;
    }
  }
  return Object.entries(agg)
    .filter(([_, v]) => v.total > 0)
    .sort(([a], [b]) => a.localeCompare(b, 'zh-CN'))
    .map(([name, v]) => ({ name, total_amount: v.total, unit: v.unit }));
}

export default function FinancePage() {
  const { user } = useAuth();
  const supabase = getBrowserClient();
  const [activeTab, setActiveTab] = useState('pending');
  const [pendingRecipes, setPendingRecipes] = useState<Recipe[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [historyRecords, setHistoryRecords] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);

  // Approve modal
  const [approveModalOpen, setApproveModalOpen] = useState(false);
  const [currentRecipe, setCurrentRecipe] = useState<Recipe | null>(null);
  const [recipeDetails, setRecipeDetails] = useState<RecipeDetail[]>([]);
  const [approvalRecords, setApprovalRecords] = useState<ApprovalRecord[]>([]);
  const [purchaseList, setPurchaseList] = useState<{ name: string }[]>([]);
  const [purchaseListFull, setPurchaseListFull] = useState<{ name: string; total_amount: number; unit: string }[]>([]);
  const [approveForm] = Form.useForm();

  // Detail modal
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailRecipe, setDetailRecipe] = useState<Recipe | null>(null);
  const [detailDetails, setDetailDetails] = useState<RecipeDetail[]>([]);

  const fetchPending = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data } = await supabase
      .from('recipes')
      .select('*, profiles:uploader_id(display_name, email)')
      .eq('status', 'pending_finance')
      .order('created_at', { ascending: false });
    setPendingRecipes((data || []) as unknown as Recipe[]);
    setLoading(false);
  }, [user, supabase]);

  const fetchPurchaseOrders = useCallback(async () => {
    // 只获取本周食谱对应的采购单
    const weekStart = dayjs().startOf('isoWeek').format('YYYY-MM-DD');
    const { data: weekRecipes } = await supabase
      .from('recipes')
      .select('id')
      .eq('week_start_date', weekStart);
    if (weekRecipes && weekRecipes.length > 0) {
      const recipeIds = weekRecipes.map(r => r.id);
      const { data } = await supabase
        .from('purchase_orders')
        .select('*')
        .in('recipe_id', recipeIds)
        .order('ingredient');
      setPurchaseOrders((data || []) as PurchaseOrder[]);
    } else {
      setPurchaseOrders([]);
    }
  }, [supabase]);

  const fetchHistory = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase.from('approval_records').select('recipe_id').eq('approver_id', user.id);
    if (data && data.length > 0) {
      const ids = data.map(d => d.recipe_id);
      const { data: recipes } = await supabase
        .from('recipes')
        .select('*, profiles:uploader_id(display_name, email)')
        .in('id', ids)
        .order('created_at', { ascending: false });
      setHistoryRecords((recipes || []) as unknown as Recipe[]);
    }
  }, [user, supabase]);

  useEffect(() => { fetchPending(); fetchPurchaseOrders(); fetchHistory(); }, [fetchPending, fetchPurchaseOrders, fetchHistory]);

  const openApproveModal = async (recipe: Recipe) => {
    setCurrentRecipe(recipe);
    approveForm.resetFields();

    const { data: details } = await supabase
      .from('recipe_details')
      .select('*')
      .eq('recipe_id', recipe.id)
      .order('date')
      .order('meal_type');
    setRecipeDetails((details || []) as RecipeDetail[]);

    const { data: records } = await supabase
      .from('approval_records')
      .select('*, profiles:approver_id(display_name, email)')
      .eq('recipe_id', recipe.id)
      .order('created_at');
    setApprovalRecords((records || []) as unknown as ApprovalRecord[]);

    // Get ingredient names for display and full aggregate for DB storage
    const ingredientNames = getIngredientNames((details || []) as RecipeDetail[]);
    setPurchaseList(ingredientNames);
    const aggregated = aggregateIngredients((details || []) as RecipeDetail[]);
    setPurchaseListFull(aggregated);

    setApproveModalOpen(true);
  };

  const handleApprove = async (result: 'approved' | 'rejected') => {
    if (!currentRecipe || !user) return;
    const { comment, reject_target } = approveForm.getFieldsValue();

    if (result === 'rejected' && !comment) {
      message.warning('退回时必须填写原因');
      return;
    }

    setLoading(true);
    try {
      await supabase.from('approval_records').insert({
        recipe_id: currentRecipe.id,
        approver_id: user.id,
        step: 'finance',
        result,
        comment,
      });

      let newStatus: string;
      let rejectStep: string | null = null;
      if (result === 'approved') {
        newStatus = 'pending_principal';
      } else {
        rejectStep = reject_target || 'kitchen';
        newStatus = rejectStep === 'health_doctor' ? 'rejected_kitchen' : 'rejected_kitchen';
      }

      await supabase.from('recipes').update({
        status: newStatus,
        reject_reason: result === 'rejected' ? comment : null,
        reject_step: rejectStep,
        updated_at: new Date().toISOString(),
      }).eq('id', currentRecipe.id);

      // If approved, create purchase orders with parsed ingredients
      if (result === 'approved' && purchaseListFull.length > 0) {
        await supabase.from('purchase_orders').insert(
          purchaseListFull.map(p => ({
            recipe_id: currentRecipe.id,
            ingredient: p.name,
            total_amount: p.total_amount,
            unit: p.unit,
            status: 'pending',
          }))
        );
      }

      // Create notifications
      const notifs: Array<{ user_id: string; type: string; title: string; content: string; related_id: string }> = [];
      if (result === 'rejected') {
        notifs.push({
          user_id: currentRecipe.uploader_id,
          type: 'finance_rejected',
          title: '财务审核退回',
          content: `您提交的${currentRecipe.week_start_date}周食谱被财务退回，原因：${comment}`,
          related_id: currentRecipe.id,
        });
      } else {
        const { data: principalUsers } = await supabase
          .from('profiles')
          .select('id')
          .eq('role', 'principal')
          .eq('is_active', true);
        (principalUsers || []).forEach((u: { id: string }) => {
          notifs.push({
            user_id: u.id,
            type: 'pending_principal',
            title: '待终审食谱',
            content: `${currentRecipe.week_start_date}周食谱已通过财务审核，待您终审`,
            related_id: currentRecipe.id,
          });
        });
      }
      if (notifs.length > 0) {
        await supabase.from('notifications').insert(notifs);
      }

      message.success(result === 'approved' ? '审核通过' : '已退回');
      setApproveModalOpen(false);
      fetchPending();
      fetchPurchaseOrders();
    } catch (err) {
      message.error('操作失败');
    }
    setLoading(false);
  };

  // 本周所需食材（去重，仅名称）
  const thisWeekIngredients = useMemo(() => {
    const names = new Set(purchaseOrders.map(p => p.ingredient));
    return Array.from(names).sort((a, b) => a.localeCompare(b, 'zh-CN'));
  }, [purchaseOrders]);

  const confirmDelivery = async (orderId: string) => {
    await supabase.from('purchase_orders').update({
      status: 'delivered',
      updated_at: new Date().toISOString(),
    }).eq('id', orderId);
    message.success('已确认到货');
    fetchPurchaseOrders();
  };

  const openDetailModal = async (recipe: Recipe) => {
    setDetailRecipe(recipe);
    const { data: details } = await supabase
      .from('recipe_details')
      .select('*')
      .eq('recipe_id', recipe.id)
      .order('date')
      .order('meal_type');
    setDetailDetails((details || []) as RecipeDetail[]);
    setDetailModalOpen(true);
  };

  const pendingColumns = [
    { title: '周开始日期', dataIndex: 'week_start_date', key: 'week_start_date', render: (v: string) => v ? dayjs(v).format('YYYY-MM-DD') : '-' },
    { title: '上传者', key: 'uploader', render: (_: unknown, r: Recipe) => (r.profiles as unknown as { display_name: string })?.display_name || '-' },
    { title: '状态', dataIndex: 'status', key: 'status', render: (s: string) => <Tag color={s === 'pending_finance' ? 'orange' : 'red'}>{RECIPE_STATUS_LABELS[s as keyof typeof RECIPE_STATUS_LABELS] || s}</Tag> },
    { title: '创建时间', dataIndex: 'created_at', key: 'created_at', render: (v: string) => dayjs(v).format('MM-DD HH:mm') },
    { title: '操作', key: 'action', render: (_: unknown, r: Recipe) => <Button type="primary" size="small" icon={<EyeOutlined />} onClick={() => openApproveModal(r)}>审核</Button> },
  ];

  const detailColumns = [
    { title: '日期', dataIndex: 'date', key: 'date', render: (v: string) => v ? dayjs(v).format('MM-DD') : '-' },
    { title: '餐别', dataIndex: 'meal_type', key: 'meal_type', render: (v: string) => MEAL_TYPE_LABELS[v as keyof typeof MEAL_TYPE_LABELS] || v },
    { title: '菜品', dataIndex: 'dish_name', key: 'dish_name' },
    { title: '食材', dataIndex: 'ingredient', key: 'ingredient', render: (v: string) => {
      const names = extractCleanIngredientNames(v);
      return names.length > 0 ? names.join('、') : v;
    }},
    { title: '备注', dataIndex: 'remark', key: 'remark' },
  ];

  const purchaseColumns = [
    { title: '序号', key: 'index', width: 60, render: (_: unknown, __: unknown, idx: number) => idx + 1 },
    { title: '食材', dataIndex: 'ingredient', key: 'ingredient' },
    {
      title: '状态', dataIndex: 'status', key: 'status',
      render: (s: string) => {
        const map: Record<string, { color: string; label: string }> = {
          pending: { color: 'orange', label: '待采购' },
          ordered: { color: 'blue', label: '已下单' },
          delivered: { color: 'green', label: '已到货' },
        };
        const info = map[s] || { color: 'default', label: s };
        return <Tag color={info.color}>{info.label}</Tag>;
      },
    },
    { title: '操作', key: 'action', render: (_: unknown, r: PurchaseOrder) => r.status !== 'delivered' && <Button size="small" type="primary" onClick={() => confirmDelivery(r.id)}>确认到货</Button> },
  ];

  const historyColumns = [
    { title: '周开始日期', dataIndex: 'week_start_date', key: 'week_start_date', render: (v: string) => v ? dayjs(v).format('YYYY-MM-DD') : '-' },
    { title: '状态', dataIndex: 'status', key: 'status', render: (s: string) => <Tag color={s === 'effective' ? 'green' : 'blue'}>{RECIPE_STATUS_LABELS[s as keyof typeof RECIPE_STATUS_LABELS] || s}</Tag> },
    { title: '操作', key: 'action', render: (_: unknown, r: Recipe) => <Button size="small" onClick={() => openDetailModal(r)}>查看详情</Button> },
  ];

  return (
    <div style={{ padding: 24 }}>
      <Tabs activeKey={activeTab} onChange={setActiveTab} items={[
        {
          key: 'pending',
          label: '待审核采购可行性',
          children: (
            <Card>
              <Table dataSource={pendingRecipes} columns={pendingColumns} rowKey="id" loading={loading}
                locale={{ emptyText: <Empty description="暂无待审核食谱" /> }} />
            </Card>
          ),
        },
        {
          key: 'purchase',
          label: '本周食材采购',
          children: (
            <Card>
              {thisWeekIngredients.length > 0 ? (
                <List
                  grid={{ gutter: 16, column: 4 }}
                  dataSource={thisWeekIngredients}
                  renderItem={(name: string) => (
                    <List.Item>
                      <Card size="small" hoverable>
                        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                          <ShoppingCartOutlined style={{ color: '#52c41a' }} />
                          <span>{name}</span>
                        </div>
                      </Card>
                    </List.Item>
                  )}
                />
              ) : (
                <Empty description="本周暂无采购食材" />
              )}
              {purchaseOrders.length > 0 && (
                <div style={{ marginTop: 24 }}>
                  <Card title="采购状态跟踪" size="small">
                    <Table dataSource={purchaseOrders} columns={purchaseColumns} rowKey="id" size="small"
                      pagination={false} />
                  </Card>
                </div>
              )}
            </Card>
          ),
        },
        {
          key: 'history',
          label: '历史记录',
          children: (
            <Card>
              <Table dataSource={historyRecords} columns={historyColumns} rowKey="id"
                locale={{ emptyText: <Empty description="暂无历史记录" /> }} />
            </Card>
          ),
        },
      ]} />

      {/* Approve Modal */}
      <Modal
        title="审核食谱"
        open={approveModalOpen}
        onCancel={() => setApproveModalOpen(false)}
        footer={null}
        width={900}
        forceRender
      >
        {currentRecipe && (
          <>
            <Descriptions column={2} size="small" bordered style={{ marginBottom: 16 }}>
              <Descriptions.Item label="周开始日期">{currentRecipe.week_start_date}</Descriptions.Item>
              <Descriptions.Item label="上传者">{(currentRecipe.profiles as unknown as { display_name: string })?.display_name}</Descriptions.Item>
              <Descriptions.Item label="状态"><Tag color="orange">{RECIPE_STATUS_LABELS[currentRecipe.status]}</Tag></Descriptions.Item>
            </Descriptions>

            <Card title="食谱详情" size="small" style={{ marginBottom: 16 }}>
              <Table dataSource={recipeDetails} columns={detailColumns} rowKey={(r: RecipeDetail) => `${r.date}-${r.meal_type}-${r.dish_name}`}
                pagination={false} size="small" />
            </Card>

            <Card title="所需食材清单" size="small" style={{ marginBottom: 16 }}>
              {purchaseList.length > 0 ? (
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {purchaseList.map((item, idx) => (
                    <Tag key={idx} color="green" style={{ fontSize: 14, padding: '4px 12px' }}>
                      {item.name}
                    </Tag>
                  ))}
                </div>
              ) : (
                <Empty description="暂无食材数据" />
              )}
            </Card>

            {approvalRecords.length > 0 && (
              <Card title="审批记录" size="small" style={{ marginBottom: 16 }}>
                <Timeline items={approvalRecords.map((r: ApprovalRecord) => ({
                  color: r.result === 'approved' ? 'green' : r.result === 'rejected' ? 'red' : 'blue',
                  content: `${(r.profiles as unknown as { display_name: string })?.display_name || '未知'} - ${r.step === 'kitchen' ? '厨房' : r.step === 'finance' ? '财务' : '园长'}审核：${r.result === 'approved' ? '通过' : '退回'}${r.comment ? `（${r.comment}）` : ''}`,
                }))} />
              </Card>
            )}

            <Card title="审核操作" size="small">
              <Form form={approveForm} layout="vertical">
                <Form.Item label="审核结果">
                  <Space>
                    <Button type="primary" icon={<CheckCircleOutlined />} loading={loading} onClick={() => handleApprove('approved')}>
                      通过 - 提交园长终审
                    </Button>
                    <Button danger icon={<CloseCircleOutlined />} loading={loading} onClick={() => handleApprove('rejected')}>
                      退回
                    </Button>
                  </Space>
                </Form.Item>
                <Form.Item label="退回目标" name="reject_target">
                  <Select placeholder="选择退回目标（默认退回至厨房）" allowClear>
                    <Select.Option value="kitchen">退回至厨房</Select.Option>
                    <Select.Option value="health_doctor">退回至保健医</Select.Option>
                  </Select>
                </Form.Item>
                <Form.Item label="审核意见" name="comment">
                  <Input.TextArea rows={3} placeholder="退回时必须填写原因" />
                </Form.Item>
              </Form>
            </Card>
          </>
        )}
      </Modal>

      {/* Detail Modal */}
      <Modal
        title="食谱详情"
        open={detailModalOpen}
        onCancel={() => setDetailModalOpen(false)}
        footer={<Button onClick={() => setDetailModalOpen(false)}>关闭</Button>}
        width={800}
        forceRender
      >
        {detailRecipe && (
          <>
            <Descriptions column={2} size="small" bordered style={{ marginBottom: 16 }}>
              <Descriptions.Item label="周开始日期">{detailRecipe.week_start_date}</Descriptions.Item>
              <Descriptions.Item label="状态"><Tag color="green">{RECIPE_STATUS_LABELS[detailRecipe.status]}</Tag></Descriptions.Item>
            </Descriptions>
            <Table dataSource={detailDetails} columns={detailColumns} rowKey={(r: RecipeDetail) => `${r.date}-${r.meal_type}-${r.dish_name}`}
              pagination={false} size="small" />
          </>
        )}
      </Modal>
    </div>
  );
}
