'use client';

import { AuthProvider } from '@/contexts/AuthContext';
import HomeContent from './HomeContent';

export default function HomePage() {
  return (
    <AuthProvider>
      <HomeContent />
    </AuthProvider>
  );
}
