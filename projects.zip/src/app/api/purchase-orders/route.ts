import { NextRequest, NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    message: 'Purchase orders are fetched client-side via Supabase SDK',
  });
}
