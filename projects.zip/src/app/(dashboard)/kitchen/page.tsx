'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  Card, Table, Tag, Button, Modal, Space, Tabs, Empty, message,
  Descriptions, Checkbox, Input, Form, Timeline, Badge,
} from 'antd';
import {
  CheckCircleOutlined, CloseCircleOutlined, EyeOutlined,
  UnorderedListOutlined,
} from '@ant-design/icons';
import { useAuth } from '@/contexts/AuthContext';
import { getBrowserClient } from '@/lib/supabase';
import {
  RECIPE_STATUS_LABELS, MEAL_TYPE_LABELS,
  type Recipe, type RecipeDetail, type ApprovalRecord, type DailyTask, type MealType,
} from '@/types';
import dayjs from 'dayjs';

export default function KitchenPage() {
  const { user, profile } = useAuth();
  const supabase = getBrowserClient();
  const [activeTab, setActiveTab] = useState('pending');
  const [pendingRecipes, setPendingRecipes] = useState<Recipe[]>([]);
  const [historyRecipes, setHistoryRecipes] = useState<Recipe[]>([]);
  const [dailyTasks, setDailyTasks] = useState<DailyTask[]>([]);
  const [loading, setLoading] = useState(false);

  // Approval modal
  const [approveModalOpen, setApproveModalOpen] = useState(false);
  const [currentRecipe, setCurrentRecipe] = useState<Recipe | null>(null);
  const [recipeDetails, setRecipeDetails] = useState<RecipeDetail[]>([]);
  const [approvalRecords, setApprovalRecords] = useState<ApprovalRecord[]>([]);
  const [approveForm] = Form.useForm();
  const [checkItems, setCheckItems] = useState({
    equipment: false, skills: false, time: false, banned: false,
  });

  // Detail modal
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailRecipe, setDetailRecipe] = useState<Recipe | null>(null);
  const [detailDetails, setDetailDetails] = useState<RecipeDetail[]>([]);
  const [detailRecords, setDetailRecords] = useState<ApprovalRecord[]>([]);

  const fetchPendingRecipes = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    const { data, error } = await supabase
      .from('recipes')
      .select('*, profiles:uploader_id(display_name, email)')
      .or('status.eq.pending_kitchen,status.eq.rejected_finance')
      .order('created_at', { ascending: false });
    if (error) message.error('获取待审核列表失败');
    else setPendingRecipes((data || []) as unknown as Recipe[]);
    setLoading(false);
  }, [user, supabase]);

  const fetchHistory = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from('approval_records')
      .select('recipe_id')
      .eq('approver_id', user.id);
    if (data && data.length > 0) {
      const recipeIds = data.map(d => d.recipe_id);
      const { data: recipes } = await supabase
        .from('recipes')
        .select('*, profiles:uploader_id(display_name, email)')
        .in('id', recipeIds)
        .order('created_at', { ascending: false });
      setHistoryRecipes((recipes || []) as unknown as Recipe[]);
    }
  }, [user, supabase]);

  const fetchDailyTasks = useCallback(async () => {
    const today = dayjs().format('YYYY-MM-DD');
    const { data } = await supabase
      .from('daily_tasks')
      .select('*')
      .eq('date', today)
      .order('meal_type');
    setDailyTasks((data || []) as DailyTask[]);
  }, [supabase]);

  useEffect(() => { fetchPendingRecipes(); fetchHistory(); fetchDailyTasks(); }, [fetchPendingRecipes, fetchHistory, fetchDailyTasks]);

  const openApproveModal = async (recipe: Recipe) => {
    setCurrentRecipe(recipe);
    setCheckItems({ equipment: false, skills: false, time: false, banned: false });
    approveForm.resetFields();

    const { data: details } = await supabase
      .from('recipe_details')
      .select('*')
      .eq('recipe_id', recipe.id)
      .order('date')
      .order('meal_type');
    setRecipeDetails((details || []) as RecipeDetail[]);

    const { data: records } = await supabase
      .from('approval_records')
      .select('*, profiles:approver_id(display_name, email)')
      .eq('recipe_id', recipe.id)
      .order('created_at');
    setApprovalRecords((records || []) as unknown as ApprovalRecord[]);

    setApproveModalOpen(true);
  };

  const handleApprove = async (result: 'approved' | 'rejected') => {
    if (!currentRecipe || !user) return;
    const comment = approveForm.getFieldValue('comment');

    if (result === 'approved') {
      const allChecked = Object.values(checkItems).every(v => v);
      if (!allChecked) {
        message.warning('请完成所有核查项后再通过');
        return;
      }
    }

    if (result === 'rejected' && !comment) {
      message.warning('退回时必须填写原因');
      return;
    }

    setLoading(true);
    try {
      const { error: recordError } = await supabase.from('approval_records').insert({
        recipe_id: currentRecipe.id,
        approver_id: user.id,
        step: 'kitchen',
        result,
        comment,
      });
      if (recordError) throw new Error(recordError.message);

      const newStatus = result === 'approved' ? 'pending_finance' : 'rejected_kitchen';
      const { error: updateError } = await supabase
        .from('recipes')
        .update({
          status: newStatus,
          reject_reason: result === 'rejected' ? comment : null,
          reject_step: result === 'rejected' ? 'kitchen' : null,
          updated_at: new Date().toISOString(),
        })
        .eq('id', currentRecipe.id);
      if (updateError) throw new Error(updateError.message);

      // If approved, create daily tasks for the week
      if (result === 'approved') {
        const tasks = recipeDetails.map(d => ({
          recipe_id: currentRecipe.id,
          date: d.date,
          meal_type: d.meal_type,
          dish_name: d.dish_name,
          is_completed: false,
        }));
        if (tasks.length > 0) {
          await supabase.from('daily_tasks').insert(tasks);
        }
      }

      // Create notifications
      const notifs: Array<{ user_id: string; type: string; title: string; content: string; related_id: string }> = [];
      if (result === 'rejected') {
        notifs.push({
          user_id: currentRecipe.uploader_id,
          type: 'kitchen_rejected',
          title: '厨房审核退回',
          content: `您提交的${currentRecipe.week_start_date}周食谱被厨房退回，原因：${comment}`,
          related_id: currentRecipe.id,
        });
      } else {
        // Notify all finance users
        const { data: financeUsers } = await supabase
          .from('profiles')
          .select('id')
          .eq('role', 'finance')
          .eq('is_active', true);
        (financeUsers || []).forEach((u: { id: string }) => {
          notifs.push({
            user_id: u.id,
            type: 'pending_finance',
            title: '待审核食谱',
            content: `${currentRecipe.week_start_date}周食谱已通过厨房审核，待您审核采购可行性`,
            related_id: currentRecipe.id,
          });
        });
      }
      if (notifs.length > 0) {
        await supabase.from('notifications').insert(notifs);
      }

      message.success(result === 'approved' ? '审核通过' : '已退回');
      setApproveModalOpen(false);
      fetchPendingRecipes();
      fetchHistory();
    } catch (err) {
      message.error('操作失败：' + (err instanceof Error ? err.message : '未知错误'));
    }
    setLoading(false);
  };

  const toggleTask = async (task: DailyTask) => {
    const newCompleted = !task.is_completed;
    await supabase.from('daily_tasks').update({
      is_completed: newCompleted,
      completed_at: newCompleted ? new Date().toISOString() : null,
    }).eq('id', task.id);
    fetchDailyTasks();
  };

  const openDetailModal = async (recipe: Recipe) => {
    setDetailRecipe(recipe);
    const { data: details } = await supabase.from('recipe_details').select('*').eq('recipe_id', recipe.id).order('date').order('meal_type');
    setDetailDetails((details || []) as RecipeDetail[]);
    const { data: records } = await supabase.from('approval_records').select('*, profiles:approver_id(display_name, email)').eq('recipe_id', recipe.id).order('created_at');
    setDetailRecords((records || []) as unknown as ApprovalRecord[]);
    setDetailModalOpen(true);
  };

  const recipeColumns = [
    {
      title: '周开始日期', dataIndex: 'week_start_date', key: 'week_start_date',
      render: (d: string) => dayjs(d).format('YYYY-MM-DD'),
    },
    {
      title: '状态', dataIndex: 'status', key: 'status',
      render: (s: string) => <Tag color={s.includes('reject') ? 'error' : 'processing'}>{RECIPE_STATUS_LABELS[s as keyof typeof RECIPE_STATUS_LABELS]}</Tag>,
    },
    {
      title: '上传者', key: 'uploader',
      render: (_: unknown, r: Recipe) => (r.profiles as { display_name: string })?.display_name || '-',
    },
    {
      title: '提交时间', dataIndex: 'created_at', key: 'created_at',
      render: (d: string) => dayjs(d).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: '操作', key: 'action',
      render: (_: unknown, r: Recipe) => (
        <Space>
          <Button size="small" icon={<EyeOutlined />} onClick={() => openDetailModal(r)}>查看</Button>
          <Button size="small" type="primary" onClick={() => openApproveModal(r)}>审核</Button>
        </Space>
      ),
    },
  ];

  const detailColumns = [
    { title: '日期', dataIndex: 'date', key: 'date', render: (d: string) => dayjs(d).format('MM-DD') },
    { title: '餐别', dataIndex: 'meal_type', key: 'meal_type', render: (t: MealType) => MEAL_TYPE_LABELS[t] },
    { title: '菜品', dataIndex: 'dish_name', key: 'dish_name' },
    { title: '食材与带量', dataIndex: 'ingredient', key: 'ingredient' },
  ];

  return (
    <div>
      <h2 style={{ marginBottom: 24 }}>厨房人员工作台</h2>
      <Tabs activeKey={activeTab} onChange={setActiveTab} items={[
        {
          key: 'pending',
          label: <span>待审核{pendingRecipes.length > 0 && <Badge count={pendingRecipes.length} style={{ marginLeft: 4 }} />}</span>,
          children: (
            <Card>
              <Table columns={recipeColumns} dataSource={pendingRecipes} rowKey="id" loading={loading}
                locale={{ emptyText: <Empty description="暂无待审核食谱" /> }} />
            </Card>
          ),
        },
        {
          key: 'daily',
          label: '今日制作任务',
          children: (
            <Card title={`${dayjs().format('YYYY年MM月DD日')} 制作任务`}>
              {dailyTasks.length === 0 ? <Empty description="今日无制作任务" /> : (
                <Table
                  columns={[
                    { title: '餐别', dataIndex: 'meal_type', key: 'meal_type', render: (t: string) => MEAL_TYPE_LABELS[t as MealType] || t },
                    { title: '菜品', dataIndex: 'dish_name', key: 'dish_name' },
                    { title: '状态', key: 'status', render: (_: unknown, r: DailyTask) => r.is_completed ? <Tag color="success">已完成</Tag> : <Tag color="processing">待制作</Tag> },
                    {
                      title: '操作', key: 'action',
                      render: (_: unknown, r: DailyTask) => (
                        <Button size="small" type={r.is_completed ? 'default' : 'primary'}
                          onClick={() => toggleTask(r)}>
                          {r.is_completed ? '撤销完成' : '标记完成'}
                        </Button>
                      ),
                    },
                  ]}
                  dataSource={dailyTasks} rowKey="id" size="small"
                />
              )}
            </Card>
          ),
        },
        {
          key: 'history',
          label: '历史记录',
          children: (
            <Card>
              <Table columns={recipeColumns.filter(c => c.key !== 'action').concat([{
                title: '操作', key: 'action',
                render: (_: unknown, r: Recipe) => <Button size="small" icon={<EyeOutlined />} onClick={() => openDetailModal(r)}>查看</Button>,
              }])} dataSource={historyRecipes} rowKey="id" />
            </Card>
          ),
        },
      ]} />

      {/* Approve Modal */}
      <Modal
        title="厨房审核"
        open={approveModalOpen}
        forceRender
        onCancel={() => setApproveModalOpen(false)}
        footer={null}
        width={800}
      >
        {currentRecipe && (
          <div>
            <Descriptions bordered size="small" column={2} style={{ marginBottom: 16 }}>
              <Descriptions.Item label="周开始日期">{dayjs(currentRecipe.week_start_date).format('YYYY-MM-DD')}</Descriptions.Item>
              <Descriptions.Item label="上传者">{(currentRecipe.profiles as { display_name: string })?.display_name}</Descriptions.Item>
            </Descriptions>

            <Card title="食谱明细" size="small" style={{ marginBottom: 16 }}>
              <Table columns={detailColumns} dataSource={recipeDetails} rowKey="id" size="small" pagination={false} />
            </Card>

            <Card title="核查项" size="small" style={{ marginBottom: 16 }}>
              <Space orientation="vertical">
                <Checkbox checked={checkItems.equipment} onChange={e => setCheckItems(p => ({ ...p, equipment: e.target.checked }))}>
                  设备：现有厨房设备可满足制作需求
                </Checkbox>
                <Checkbox checked={checkItems.skills} onChange={e => setCheckItems(p => ({ ...p, skills: e.target.checked }))}>
                  技能：厨师团队具备相关烹饪技能
                </Checkbox>
                <Checkbox checked={checkItems.time} onChange={e => setCheckItems(p => ({ ...p, time: e.target.checked }))}>
                  时间：可在规定时间内完成制作
                </Checkbox>
                <Checkbox checked={checkItems.banned} onChange={e => setCheckItems(p => ({ ...p, banned: e.target.checked }))}>
                  禁用菜品：菜品中不含禁用食材
                </Checkbox>
              </Space>
            </Card>

            {approvalRecords.length > 0 && (
              <Card title="历史审核记录" size="small" style={{ marginBottom: 16 }}>
                <Timeline items={approvalRecords.map(r => ({
                  color: r.result === 'approved' ? 'green' : 'red',
                  content: <div>{r.step === 'kitchen' ? '厨房' : r.step === 'finance' ? '财务' : '园长'}：
                    <Tag color={r.result === 'approved' ? 'success' : 'error'}>{r.result === 'approved' ? '通过' : '退回'}</Tag>
                    {r.comment && <span style={{ color: '#666' }}>{r.comment}</span>}
                  </div>,
                }))} />
              </Card>
            )}

            <Form form={approveForm}>
              <Form.Item name="comment" label="审核意见">
                <Input.TextArea rows={3} placeholder="退回时必须填写原因" />
              </Form.Item>
            </Form>

            <Space>
              <Button type="primary" icon={<CheckCircleOutlined />} onClick={() => handleApprove('approved')} loading={loading}>
                审核通过
              </Button>
              <Button danger icon={<CloseCircleOutlined />} onClick={() => handleApprove('rejected')} loading={loading}>
                退回保健室
              </Button>
            </Space>
          </div>
        )}
      </Modal>

      {/* Detail Modal */}
      <Modal
        title="食谱详情"
        open={detailModalOpen}
        onCancel={() => setDetailModalOpen(false)}
        footer={null}
        width={800}
      >
        {detailRecipe && (
          <div>
            <Descriptions bordered size="small" column={2} style={{ marginBottom: 16 }}>
              <Descriptions.Item label="周开始日期">{dayjs(detailRecipe.week_start_date).format('YYYY-MM-DD')}</Descriptions.Item>
              <Descriptions.Item label="状态"><Tag>{RECIPE_STATUS_LABELS[detailRecipe.status as keyof typeof RECIPE_STATUS_LABELS]}</Tag></Descriptions.Item>
            </Descriptions>
            <Table columns={detailColumns} dataSource={detailDetails} rowKey="id" size="small" pagination={false} />
            {detailRecords.length > 0 && (
              <Card title="审核记录" size="small" style={{ marginTop: 16 }}>
                <Timeline items={detailRecords.map(r => ({
                  color: r.result === 'approved' ? 'green' : 'red',
                  content: <div>{r.step}：<Tag color={r.result === 'approved' ? 'success' : 'error'}>{r.result === 'approved' ? '通过' : '退回'}</Tag>{r.comment && ` - ${r.comment}`}</div>,
                }))} />
              </Card>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
