'use client';

import React, { useEffect, useState } from 'react';
import { Layout, Menu, Avatar, Dropdown, Badge, Typography, Spin, List, Button, Empty } from 'antd';
import {
  HeartOutlined,
  FireOutlined,
  DollarOutlined,
  CrownOutlined,
  RetweetOutlined,
  BellOutlined,
  LogoutOutlined,
  UserOutlined,
  DashboardOutlined,
  UserAddOutlined,
  BarChartOutlined,
  CheckCircleOutlined,
} from '@ant-design/icons';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter, usePathname } from 'next/navigation';
import { ROLE_LABELS, type UserRole } from '@/types';
import { getBrowserClient } from '@/lib/supabase';
import dayjs from 'dayjs';

const { Header, Sider, Content } = Layout;
const { Text } = Typography;

const ROLE_MENU_ITEMS: Record<UserRole, Array<{ key: string; label: string; icon: React.ReactNode }>> = {
  health_doctor: [
    { key: '/health-doctor', label: '保健医工作台', icon: <HeartOutlined /> },
    { key: '/tracking', label: '流程追踪', icon: <RetweetOutlined /> },
  ],
  kitchen: [
    { key: '/kitchen', label: '厨房人员工作台', icon: <FireOutlined /> },
    { key: '/tracking', label: '流程追踪', icon: <RetweetOutlined /> },
  ],
  finance: [
    { key: '/finance', label: '财务工作台', icon: <DollarOutlined /> },
    { key: '/tracking', label: '流程追踪', icon: <RetweetOutlined /> },
  ],
  principal: [
    { key: '/principal', label: '最终审核', icon: <CrownOutlined /> },
    { key: '/principal/users', label: '人员管理', icon: <UserAddOutlined /> },
    { key: '/principal/stats', label: '数据统计', icon: <BarChartOutlined /> },
    { key: '/tracking', label: '流程追踪', icon: <RetweetOutlined /> },
  ],
};

interface NotificationItem {
  id: string;
  title: string;
  content: string;
  is_read: boolean;
  created_at: string;
  related_id: string | null;
}

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const { user, profile, signOut, loading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [notifOpen, setNotifOpen] = useState(false);
  const supabase = getBrowserClient();

  const fetchNotifications = async () => {
    if (!user) return;
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(20);
    if (!error && data) {
      setNotifications(data as NotificationItem[]);
      setUnreadCount(data.filter((n: NotificationItem) => !n.is_read).length);
    }
  };

  useEffect(() => {
    if (!user) return;
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 15000);
    return () => clearInterval(interval);
  }, [user]);

  const handleNotificationClick = async (notif: NotificationItem) => {
    if (!notif.is_read) {
      await supabase
        .from('notifications')
        .update({ is_read: true })
        .eq('id', notif.id);
      fetchNotifications();
    }
    if (notif.related_id) {
      router.push('/tracking');
    }
  };

  const handleMarkAllRead = async () => {
    if (!user) return;
    const unreadIds = notifications.filter(n => !n.is_read).map(n => n.id);
    if (unreadIds.length === 0) return;
    await supabase
      .from('notifications')
      .update({ is_read: true })
      .in('id', unreadIds);
    fetchNotifications();
  };

  const handleSignOut = async () => {
    try {
      await signOut();
    } catch (err) {
      console.error('Sign out error:', err);
    }
    router.push('/');
  };

  if (loading || !profile) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
        <Spin size="large" />
      </div>
    );
  }

  const menuItems = ROLE_MENU_ITEMS[profile.role] || [];
  const defaultKey = pathname || menuItems[0]?.key || '/';

  const userMenu = {
    items: [
      {
        key: 'profile',
        icon: <UserOutlined />,
        label: `${profile.display_name || profile.email}`,
        disabled: true,
      },
      {
        key: 'role',
        icon: <DashboardOutlined />,
        label: `角色：${ROLE_LABELS[profile.role]}`,
        disabled: true,
      },
      { type: 'divider' as const },
      {
        key: 'logout',
        icon: <LogoutOutlined />,
        label: '退出登录',
        onClick: handleSignOut,
      },
    ],
  };

  const notifDropdown = {
    items: [
      {
        key: 'notif-list',
        label: (
          <div style={{ width: 340, maxHeight: 400, overflow: 'auto' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, padding: '0 4px' }}>
              <Text strong>通知消息</Text>
              {unreadCount > 0 && (
                <Button type="link" size="small" onClick={handleMarkAllRead}>
                  全部已读
                </Button>
              )}
            </div>
            {notifications.length === 0 ? (
              <Empty description="暂无通知" image={Empty.PRESENTED_IMAGE_SIMPLE} />
            ) : (
              <List
                size="small"
                dataSource={notifications}
                renderItem={(item: NotificationItem) => (
                  <List.Item
                    style={{
                      cursor: 'pointer',
                      background: item.is_read ? 'transparent' : '#f6ffed',
                      padding: '8px 12px',
                      borderRadius: 4,
                    }}
                    onClick={() => handleNotificationClick(item)}
                  >
                    <List.Item.Meta
                      title={
                        <span style={{ fontWeight: item.is_read ? 400 : 600, fontSize: 13 }}>
                          {item.title}
                        </span>
                      }
                      description={
                        <div>
                          <div style={{ fontSize: 12, color: '#666' }}>{item.content}</div>
                          <div style={{ fontSize: 11, color: '#aaa', marginTop: 2 }}>
                            {dayjs(item.created_at).format('MM-DD HH:mm')}
                          </div>
                        </div>
                      }
                    />
                    {!item.is_read && <CheckCircleOutlined style={{ color: '#52c41a', fontSize: 14 }} />}
                  </List.Item>
                )}
              />
            )}
          </div>
        ),
      },
    ],
  };

  return (
    <Layout style={{ minHeight: '100vh' }}>
      <Sider
        width={220}
        style={{
          background: '#fff',
          borderRight: '1px solid #f0f0f0',
        }}
      >
        <div style={{
          height: 64,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          borderBottom: '1px solid #f0f0f0',
          gap: 8,
        }}>
          <span style={{ fontSize: 28 }}>🍎</span>
          <Text strong style={{ fontSize: 16, color: '#52c41a' }}>餐饮管理系统</Text>
        </div>
        <Menu
          mode="inline"
          selectedKeys={[defaultKey]}
          items={menuItems.map((item) => ({
            key: item.key,
            icon: item.icon,
            label: item.label,
            onClick: () => router.push(item.key),
          }))}
          style={{ borderRight: 0, marginTop: 8 }}
        />
      </Sider>
      <Layout>
        <Header style={{
          background: '#fff',
          padding: '0 24px',
          display: 'flex',
          justifyContent: 'flex-end',
          alignItems: 'center',
          borderBottom: '1px solid #f0f0f0',
          gap: 16,
          height: 64,
        }}>
          <Dropdown
            menu={notifDropdown}
            placement="bottomRight"
            trigger={['click']}
            onOpenChange={setNotifOpen}
          >
            <Badge count={unreadCount} size="small">
              <BellOutlined style={{ fontSize: 18, cursor: 'pointer', color: notifOpen ? '#52c41a' : undefined }} />
            </Badge>
          </Dropdown>
          <Dropdown menu={userMenu} placement="bottomRight">
            <div style={{ cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}>
              <Avatar style={{ background: '#52c41a' }} icon={<UserOutlined />} />
              <Text>{profile.display_name || profile.email}</Text>
            </div>
          </Dropdown>
        </Header>
        <Content style={{
          margin: 24,
          padding: 24,
          background: '#fff',
          borderRadius: 8,
          minHeight: 280,
          overflow: 'auto',
        }}>
          {children}
        </Content>
      </Layout>
    </Layout>
  );
}
