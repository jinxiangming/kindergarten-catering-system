export type UserRole = 'health_doctor' | 'kitchen' | 'finance' | 'principal';

export const ROLE_LABELS: Record<UserRole, string> = {
  health_doctor: '保健医',
  kitchen: '厨房人员',
  finance: '财务人员',
  principal: '园长',
};

export type RecipeStatus =
  | 'draft'
  | 'pending_kitchen'
  | 'pending_finance'
  | 'pending_principal'
  | 'approved'
  | 'rejected_kitchen'
  | 'rejected_finance'
  | 'rejected_principal'
  | 'effective'
  | 'voided';

export const RECIPE_STATUS_LABELS: Record<RecipeStatus, string> = {
  draft: '草稿',
  pending_kitchen: '待厨房审核',
  pending_finance: '待财务审核',
  pending_principal: '待园长终审',
  approved: '已通过',
  rejected_kitchen: '厨房退回',
  rejected_finance: '财务退回',
  rejected_principal: '园长退回',
  effective: '已生效',
  voided: '已作废',
};

export type MealType = 'breakfast' | 'morning_snack' | 'lunch' | 'afternoon_snack';

export const MEAL_TYPE_LABELS: Record<MealType, string> = {
  breakfast: '元气早餐',
  morning_snack: '能量加餐',
  lunch: '营养中餐',
  afternoon_snack: '均衡午点',
};

export const MEAL_TYPE_ORDER: MealType[] = ['breakfast', 'morning_snack', 'lunch', 'afternoon_snack'];

export type ApprovalStep = 'kitchen' | 'finance' | 'principal';

export type ApprovalResult = 'approved' | 'rejected';

export interface Profile {
  id: string;
  email: string;
  display_name: string | null;
  role: UserRole;
  is_active: boolean;
  created_at: string;
  updated_at: string | null;
}

export interface Recipe {
  id: string;
  uploader_id: string;
  week_start_date: string;
  status: RecipeStatus;
  excel_url: string | null;
  reject_reason: string | null;
  reject_step: string | null;
  created_at: string;
  updated_at: string | null;
  profiles?: Profile;
}

export interface RecipeDetail {
  id: string;
  recipe_id: string;
  date: string;
  meal_type: MealType;
  dish_name: string;
  ingredient: string;
  amount: number;
  remark: string | null;
  created_at: string;
}

export interface ApprovalRecord {
  id: string;
  recipe_id: string;
  approver_id: string;
  step: ApprovalStep;
  result: ApprovalResult;
  comment: string | null;
  created_at: string;
  profiles?: Profile;
}

export interface PurchaseOrder {
  id: string;
  recipe_id: string;
  ingredient: string;
  total_amount: number;
  unit: string;
  status: 'pending' | 'ordered' | 'delivered' | 'cancelled';
  created_at: string;
  updated_at: string | null;
}

export interface DailyTask {
  id: string;
  recipe_id: string;
  date: string;
  meal_type: string;
  dish_name: string;
  is_completed: boolean;
  completed_at: string | null;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  content: string | null;
  related_id: string | null;
  is_read: boolean;
  created_at: string;
}

// Excel 导入行类型
export interface RecipeExcelRow {
  日期: string;
  餐别: string;
  菜品: string;
  食材: string;
  带量克: number | string;
  备注: string;
}
