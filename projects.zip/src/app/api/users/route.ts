import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    message: 'Users are managed client-side via Supabase Auth and profiles table',
  });
}

export async function POST() {
  return NextResponse.json({
    message: 'User creation is handled via Supabase Auth signUp with metadata',
  });
}
