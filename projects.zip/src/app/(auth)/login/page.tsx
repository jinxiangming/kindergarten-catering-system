'use client';

import { AuthProvider } from '@/contexts/AuthContext';
import LoginContent from './LoginContent';

export default function LoginPage() {
  return (
    <AuthProvider>
      <LoginContent />
    </AuthProvider>
  );
}
