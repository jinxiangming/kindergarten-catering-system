'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  Card, Table, Tag, Steps, Empty, Spin, Input, Space, Timeline,
} from 'antd';
import { SearchOutlined } from '@ant-design/icons';
import { useAuth } from '@/contexts/AuthContext';
import { getBrowserClient } from '@/lib/supabase';
import {
  RECIPE_STATUS_LABELS,
  type Recipe, type ApprovalRecord,
} from '@/types';
import dayjs from 'dayjs';

const STATUS_STEP_MAP: Record<string, number> = {
  draft: 0,
  pending_kitchen: 1,
  rejected_kitchen: 0,
  pending_finance: 2,
  rejected_finance: 1,
  pending_principal: 3,
  rejected_principal: 2,
  approved: 4,
  effective: 4,
  voided: -1,
};

export default function TrackingPage() {
  const { user } = useAuth();
  const supabase = getBrowserClient();
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [records, setRecords] = useState<ApprovalRecord[]>([]);

  const fetchRecipes = useCallback(async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('recipes')
      .select('*, profiles:uploader_id(display_name, email)')
      .order('created_at', { ascending: false })
      .limit(50);
    if (!error) setRecipes((data || []) as unknown as Recipe[]);
    setLoading(false);
  }, [supabase]);

  useEffect(() => { fetchRecipes(); }, [fetchRecipes]);

  const fetchRecords = async (recipeId: string) => {
    setSelectedId(recipeId);
    const { data } = await supabase
      .from('approval_records')
      .select('*, profiles:approver_id(display_name, email)')
      .eq('recipe_id', recipeId)
      .order('created_at');
    setRecords((data || []) as unknown as ApprovalRecord[]);
  };

  const filteredRecipes = recipes.filter(r =>
    r.week_start_date.includes(search) ||
    (r.profiles as { display_name: string })?.display_name?.includes(search) ||
    RECIPE_STATUS_LABELS[r.status as keyof typeof RECIPE_STATUS_LABELS]?.includes(search)
  );

  const selectedRecipe = recipes.find(r => r.id === selectedId);

  return (
    <div>
      <h2 style={{ marginBottom: 24 }}>流程追踪看板</h2>
      <Space style={{ marginBottom: 16 }}>
        <Input
          prefix={<SearchOutlined />}
          placeholder="搜索日期、上传者、状态..."
          value={search}
          onChange={e => setSearch(e.target.value)}
          style={{ width: 300 }}
        />
      </Space>

      <div style={{ display: 'flex', gap: 16 }}>
        <Card style={{ flex: 1 }}>
          <Table
            columns={[
              {
                title: '周开始日期', dataIndex: 'week_start_date', key: 'week_start_date',
                render: (d: string) => dayjs(d).format('YYYY-MM-DD'),
              },
              {
                title: '上传者', key: 'uploader',
                render: (_: unknown, r: Recipe) => (r.profiles as { display_name: string })?.display_name || '-',
              },
              {
                title: '当前状态', dataIndex: 'status', key: 'status',
                render: (s: string) => {
                  const color = s.includes('reject') ? 'error' : s === 'effective' ? 'success' : 'processing';
                  return <Tag color={color}>{RECIPE_STATUS_LABELS[s as keyof typeof RECIPE_STATUS_LABELS]}</Tag>;
                },
              },
              {
                title: '当前节点', dataIndex: 'status', key: 'step',
                render: (s: string) => {
                  const stepMap: Record<string, string> = {
                    draft: '草稿', pending_kitchen: '厨房审核中', pending_finance: '财务审核中',
                    pending_principal: '园长终审中', approved: '已通过', effective: '已生效',
                    rejected_kitchen: '厨房退回→保健室', rejected_finance: '财务退回', rejected_principal: '园长退回',
                    voided: '已作废',
                  };
                  return stepMap[s] || s;
                },
              },
              {
                title: '操作', key: 'action',
                render: (_: unknown, r: Recipe) => (
                  <Tag color={selectedId === r.id ? 'green' : 'default'} style={{ cursor: 'pointer' }}
                    onClick={() => fetchRecords(r.id)}>
                    查看进度
                  </Tag>
                ),
              },
            ]}
            dataSource={filteredRecipes}
            rowKey="id"
            loading={loading}
            size="small"
            pagination={{ pageSize: 10 }}
          />
        </Card>

        <Card style={{ width: 360 }} title="审核进度">
          {selectedRecipe ? (
            <div>
              <div style={{ marginBottom: 16 }}>
                <strong>{dayjs(selectedRecipe.week_start_date).format('YYYY-MM-DD')} 周食谱</strong>
                <Tag color={selectedRecipe.status === 'effective' ? 'success' : 'processing'} style={{ marginLeft: 8 }}>
                  {RECIPE_STATUS_LABELS[selectedRecipe.status as keyof typeof RECIPE_STATUS_LABELS]}
                </Tag>
              </div>
              <Steps
                orientation="vertical"
                size="small"
                current={STATUS_STEP_MAP[selectedRecipe.status] ?? 0}
                items={[
                  { title: '保健医提交', description: '上传食谱' },
                  { title: '厨房审核', description: '核查可制作性' },
                  { title: '财务审核', description: '核查采购可行性' },
                  { title: '园长终审', description: '最终拍板' },
                  { title: '食谱生效', description: '生成采购单' },
                ]}
              />
              {records.length > 0 && (
                <div style={{ marginTop: 16 }}>
                  <h4>审核时间线</h4>
                  <Timeline
                    items={records.map(r => ({
                      color: r.result === 'approved' ? 'green' : 'red',
                      content: (
                        <div>
                          <div>{r.step === 'kitchen' ? '厨房' : r.step === 'finance' ? '财务' : '园长'}
                            <Tag color={r.result === 'approved' ? 'success' : 'error'} style={{ marginLeft: 4 }}>
                              {r.result === 'approved' ? '通过' : '退回'}
                            </Tag>
                          </div>
                          {r.profiles && <div style={{ fontSize: 12, color: '#888' }}>{(r.profiles as { display_name: string }).display_name}</div>}
                          {r.comment && <div style={{ fontSize: 12, color: '#666' }}>{r.comment}</div>}
                          <div style={{ fontSize: 11, color: '#aaa' }}>{dayjs(r.created_at).format('MM-DD HH:mm')}</div>
                        </div>
                      ),
                    }))}
                  />
                </div>
              )}
            </div>
          ) : (
            <Empty description="请选择食谱查看进度" />
          )}
        </Card>
      </div>
    </div>
  );
}
