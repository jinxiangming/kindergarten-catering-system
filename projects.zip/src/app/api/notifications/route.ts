import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const user_id = searchParams.get('user_id');
  return NextResponse.json({
    message: 'Notifications are fetched client-side via Supabase SDK',
    user_id,
  });
}

export async function PATCH(request: NextRequest) {
  try {
    const { id, is_read } = await request.json();
    return NextResponse.json({
      message: 'Notification updates are handled client-side via Supabase SDK',
      notification_id: id,
      is_read,
    });
  } catch {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
}
