'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  Card, Table, Tag, Button, Modal, Space, Empty, message,
  Form, Input, Select, Popconfirm,
} from 'antd';
import {
  UserAddOutlined, KeyOutlined, DeleteOutlined,
} from '@ant-design/icons';
import { useAuth } from '@/contexts/AuthContext';
import { getBrowserClient } from '@/lib/supabase';
import { ROLE_LABELS, type Profile, type UserRole } from '@/types';
import dayjs from 'dayjs';

export default function UsersPage() {
  const { user } = useAuth();
  const supabase = getBrowserClient();
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(false);
  const [addUserModalOpen, setAddUserModalOpen] = useState(false);
  const [addUserForm] = Form.useForm();
  const [resetPwdModalOpen, setResetPwdModalOpen] = useState(false);
  const [resetPwdUser, setResetPwdUser] = useState<Profile | null>(null);
  const [resetPwdForm] = Form.useForm();

  const fetchUsers = useCallback(async () => {
    setLoading(true);
    const { data: userList } = await supabase.from('profiles').select('*').order('created_at');
    setUsers((userList || []) as Profile[]);
    setLoading(false);
  }, [supabase]);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const handleAddUser = async () => {
    const values = await addUserForm.validateFields();
    try {
      const email = values.email.includes('@') ? values.email : `${values.email}@kindergarten.com`;
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          password: values.password,
          display_name: values.display_name,
          role: values.role,
        }),
      });
      const data = await res.json();
      if (data.error) throw new Error(data.error);
      message.success('用户创建成功，可直接登录');
      setAddUserModalOpen(false);
      addUserForm.resetFields();
      fetchUsers();
    } catch (err) {
      message.error('创建用户失败：' + (err instanceof Error ? err.message : '未知错误'));
    }
  };

  const userColumns = [
    { title: '姓名', dataIndex: 'display_name', key: 'display_name', render: (t: string | null) => t || '-' },
    { title: '用户名', dataIndex: 'email', key: 'email', render: (e: string) => e ? e.replace('@kindergarten.com', '') : '-' },
    {
      title: '角色', dataIndex: 'role', key: 'role',
      render: (r: UserRole) => <Tag color="green">{ROLE_LABELS[r]}</Tag>,
    },
    {
      title: '状态', dataIndex: 'is_active', key: 'is_active',
      render: (a: boolean) => a ? <Tag color="success">启用</Tag> : <Tag color="default">禁用</Tag>,
    },
    {
      title: '创建时间', dataIndex: 'created_at', key: 'created_at',
      render: (d: string) => dayjs(d).format('YYYY-MM-DD'),
    },
    {
      title: '操作', key: 'action',
      render: (_: unknown, r: Profile) => (
        <Space size="small">
          <Popconfirm
            title={`确定${r.is_active ? '禁用' : '启用'}该用户？`}
            onConfirm={async () => {
              await supabase.from('profiles').update({ is_active: !r.is_active }).eq('id', r.id);
              fetchUsers();
              message.success('操作成功');
            }}
          >
            <Button size="small" danger={r.is_active}>{r.is_active ? '禁用' : '启用'}</Button>
          </Popconfirm>
          <Button size="small" icon={<KeyOutlined />} onClick={() => { setResetPwdUser(r); setResetPwdModalOpen(true); }}>重置密码</Button>
          {user?.id !== r.id && (
            <Popconfirm
              title="确定删除该用户？此操作不可恢复！"
              onConfirm={async () => {
                try {
                  const res = await fetch('/api/users/delete', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ userId: r.id }),
                  });
                  const data = await res.json();
                  if (data.error) throw new Error(data.error);
                  message.success('用户已删除');
                  fetchUsers();
                } catch (err) {
                  message.error('删除失败：' + (err instanceof Error ? err.message : '未知错误'));
                }
              }}
            >
              <Button size="small" danger icon={<DeleteOutlined />}>删除</Button>
            </Popconfirm>
          )}
        </Space>
      ),
    },
  ];

  return (
    <div>
      <h2 style={{ marginBottom: 24 }}>人员管理</h2>
      <Card extra={<Button type="primary" icon={<UserAddOutlined />} onClick={() => setAddUserModalOpen(true)}>创建用户</Button>}>
        <Table columns={userColumns} dataSource={users} rowKey="id" loading={loading} />
      </Card>

      {/* Add User Modal */}
      <Modal
        title="创建新用户"
        open={addUserModalOpen}
        forceRender
        onCancel={() => setAddUserModalOpen(false)}
        onOk={handleAddUser}
        okText="创建"
      >
        <Form form={addUserForm} layout="vertical">
          <Form.Item name="display_name" label="姓名" rules={[{ required: true, message: '请输入姓名' }]}>
            <Input placeholder="请输入姓名" />
          </Form.Item>
          <Form.Item name="email" label="用户名" rules={[{ required: true, message: '请输入用户名' }]}>
            <Input placeholder="请输入用户名" />
          </Form.Item>
          <Form.Item name="password" label="密码" rules={[{ required: true, message: '请输入密码' }, { min: 6, message: '密码至少6位' }]}>
            <Input.Password placeholder="请输入密码" />
          </Form.Item>
          <Form.Item name="role" label="角色" rules={[{ required: true, message: '请选择角色' }]}>
            <Select placeholder="请选择角色">
              <Select.Option value="health_doctor">保健医</Select.Option>
              <Select.Option value="kitchen">厨房人员</Select.Option>
              <Select.Option value="finance">财务人员</Select.Option>
              <Select.Option value="principal">园长</Select.Option>
            </Select>
          </Form.Item>
        </Form>
      </Modal>

      {/* Reset Password Modal */}
      <Modal
        title="重置密码"
        open={resetPwdModalOpen}
        forceRender
        onCancel={() => { setResetPwdModalOpen(false); setResetPwdUser(null); resetPwdForm.resetFields(); }}
        onOk={async () => {
          try {
            const values = await resetPwdForm.validateFields();
            if (!resetPwdUser) return;
            const res = await fetch('/api/users/reset-password', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ userId: resetPwdUser.id, newPassword: values.newPassword }),
            });
            const data = await res.json();
            if (data.error) throw new Error(data.error);
            message.success(`已重置 ${resetPwdUser.display_name || '该用户'} 的密码`);
            setResetPwdModalOpen(false);
            setResetPwdUser(null);
            resetPwdForm.resetFields();
          } catch (err) {
            if (err instanceof Error) message.error('重置失败：' + err.message);
          }
        }}
        okText="确认重置"
      >
        {resetPwdUser && (
          <div>
            <p style={{ marginBottom: 16 }}>正在为用户 <strong>{resetPwdUser.display_name}</strong>（{resetPwdUser.email?.replace('@kindergarten.com', '')}）重置密码</p>
            <Form form={resetPwdForm} layout="vertical">
              <Form.Item name="newPassword" label="新密码" rules={[{ required: true, message: '请输入新密码' }, { min: 6, message: '密码至少6位' }]}>
                <Input.Password placeholder="请输入新密码（至少6位）" />
              </Form.Item>
              <Form.Item name="confirmPassword" label="确认密码" rules={[
                { required: true, message: '请确认新密码' },
                ({ getFieldValue }: { getFieldValue: (name: string) => string }) => ({
                  validator(_: unknown, value: string) {
                    if (!value || getFieldValue('newPassword') === value) {
                      return Promise.resolve();
                    }
                    return Promise.reject(new Error('两次输入的密码不一致'));
                  },
                }),
              ]}>
                <Input.Password placeholder="请再次输入新密码" />
              </Form.Item>
            </Form>
          </div>
        )}
      </Modal>
    </div>
  );
}
