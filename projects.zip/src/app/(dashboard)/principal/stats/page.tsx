'use client';

import React, { useState, useEffect, useCallback } from 'react';
import { Card, Tag, Row, Col, Statistic, Empty } from 'antd';
import { getBrowserClient } from '@/lib/supabase';
import { RECIPE_STATUS_LABELS, ROLE_LABELS, type Profile, type Recipe, type UserRole } from '@/types';

export default function StatsPage() {
  const supabase = getBrowserClient();
  const [totalRecipes, setTotalRecipes] = useState(0);
  const [effectiveRecipes, setEffectiveRecipes] = useState(0);
  const [allRecipes, setAllRecipes] = useState<Recipe[]>([]);
  const [users, setUsers] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(false);

  const fetchData = useCallback(async () => {
    setLoading(true);
    const { count: total } = await supabase.from('recipes').select('*', { count: 'exact', head: true });
    const { count: effective } = await supabase.from('recipes').select('*', { count: 'exact', head: true }).eq('status', 'effective');
    setTotalRecipes(total || 0);
    setEffectiveRecipes(effective || 0);

    const { data: all } = await supabase.from('recipes').select('*').order('created_at', { ascending: false }).limit(100);
    setAllRecipes((all || []) as Recipe[]);

    const { data: userList } = await supabase.from('profiles').select('*').order('created_at');
    setUsers((userList || []) as Profile[]);
    setLoading(false);
  }, [supabase]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const executionRate = totalRecipes > 0 ? Math.round((effectiveRecipes / totalRecipes) * 100) : 0;

  return (
    <div>
      <h2 style={{ marginBottom: 24 }}>数据统计</h2>
      <Row gutter={16}>
        <Col span={6}>
          <Card loading={loading}><Statistic title="食谱总数" value={totalRecipes} /></Card>
        </Col>
        <Col span={6}>
          <Card loading={loading}><Statistic title="已生效" value={effectiveRecipes} styles={{ content: { color: '#52c41a' } }} /></Card>
        </Col>
        <Col span={6}>
          <Card loading={loading}><Statistic title="执行率" value={executionRate} suffix="%" styles={{ content: { color: executionRate >= 80 ? '#52c41a' : '#faad14' } }} /></Card>
        </Col>
        <Col span={6}>
          <Card loading={loading}><Statistic title="系统用户" value={users.length} /></Card>
        </Col>
        <Col span={12} style={{ marginTop: 16 }}>
          <Card title="角色分布" loading={loading}>
            {(['health_doctor', 'kitchen', 'finance', 'principal'] as UserRole[]).map(role => (
              <div key={role} style={{ marginBottom: 8 }}>
                <Tag color="green">{ROLE_LABELS[role]}</Tag>
                <span>{users.filter(u => u.role === role).length} 人</span>
              </div>
            ))}
          </Card>
        </Col>
        <Col span={12} style={{ marginTop: 16 }}>
          <Card title="食谱状态分布" loading={loading}>
            {Object.entries(RECIPE_STATUS_LABELS).map(([key, label]) => {
              const count = allRecipes.filter(r => r.status === key).length;
              if (count === 0) return null;
              return <div key={key} style={{ marginBottom: 8 }}><Tag>{label}</Tag> {count} 份</div>;
            })}
            {allRecipes.length === 0 && <Empty description="暂无数据" />}
          </Card>
        </Col>
      </Row>
    </div>
  );
}
