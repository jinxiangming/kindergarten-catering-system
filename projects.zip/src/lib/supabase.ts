'use client';

import { createClient, SupabaseClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || process.env.COZE_SUPABASE_URL || '';
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || process.env.COZE_SUPABASE_ANON_KEY || '';
const supabaseServiceKey = process.env.NEXT_PUBLIC_SUPABASE_SERVICE_ROLE_KEY || process.env.COZE_SUPABASE_SERVICE_ROLE_KEY || '';

// Check if Supabase is configured
export function isSupabaseConfigured(): boolean {
  return !!(supabaseUrl && supabaseAnonKey);
}

// We use untyped client to avoid TS errors since we don't have generated types from Supabase
// The actual data types are enforced by our TypeScript interfaces in @/types
export type TypedSupabaseClient = SupabaseClient;

export function getSupabaseClient(token?: string): TypedSupabaseClient {
  const key = token ? supabaseAnonKey : (supabaseServiceKey || supabaseAnonKey);
  const options: Record<string, unknown> = {
    auth: {
      autoRefreshToken: true,
      persistSession: true,
    },
  };

  if (token) {
    options.global = {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    };
  }

  return createClient(supabaseUrl, key, options);
}

// Browser-side singleton client (uses anon key with user session)
let browserClient: TypedSupabaseClient | null = null;

export function getBrowserClient(): TypedSupabaseClient {
  if (!browserClient) {
    browserClient = createClient(supabaseUrl, supabaseAnonKey, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
      },
    });
  }
  return browserClient;
}
