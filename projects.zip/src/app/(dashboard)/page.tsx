'use client';

import { useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import type { UserRole } from '@/types';
import { Spin } from 'antd';

const ROLE_HOME: Record<UserRole, string> = {
  health_doctor: '/health-doctor',
  kitchen: '/kitchen',
  finance: '/finance',
  principal: '/principal',
};

export default function DashboardPage() {
  const { profile, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading || !profile) return;
    router.replace(ROLE_HOME[profile.role]);
  }, [profile, loading, router]);

  return (
    <div style={{ minHeight: '60vh', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
      <Spin size="large" />
    </div>
  );
}
