import { NextRequest, NextResponse } from 'next/server';
import { getServerClient } from '@/lib/supabase-server';

export async function POST(request: NextRequest) {
  try {
    const { email, password, display_name, role } = await request.json();
    if (!email || !password || !role) {
      return NextResponse.json({ error: '缺少必填字段' }, { status: 400 });
    }

    const supabase = getServerClient();

    // Use admin API to create user with auto-confirm
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true, // Auto-confirm email so user can login immediately
      user_metadata: {
        name: display_name,
        role,
      },
    });

    if (error) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }

    if (data.user) {
      // Insert or update profile record (trigger may have already created it)
      const { error: profileError } = await supabase
        .from('profiles')
        .upsert({
          id: data.user.id,
          email: email,
          display_name: display_name,
          role,
          is_active: true,
        });

      if (profileError) {
        return NextResponse.json({ error: profileError.message }, { status: 400 });
      }
    }

    return NextResponse.json({ message: '用户创建成功', user_id: data.user?.id });
  } catch (err) {
    const message = err instanceof Error ? err.message : '创建用户失败';
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
