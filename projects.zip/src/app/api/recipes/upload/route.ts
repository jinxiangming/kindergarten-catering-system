import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  try {
    // Excel parsing is done client-side with xlsx library
    return NextResponse.json({
      message: 'Excel parsing is handled client-side with xlsx library',
      supported_formats: ['.xlsx', '.xls'],
    });
  } catch {
    return NextResponse.json({ error: 'Invalid request' }, { status: 400 });
  }
}
