'use client';

import React, { useState } from 'react';
import { Form, Input, Button, Card, Typography, message, Space } from 'antd';
import { UserOutlined, LockOutlined } from '@ant-design/icons';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import type { UserRole } from '@/types';

const { Title, Text } = Typography;

const ROLE_HOME: Record<UserRole, string> = {
  health_doctor: '/health-doctor',
  kitchen: '/kitchen',
  finance: '/finance',
  principal: '/principal',
};

export default function LoginContent() {
  const { signIn, profile, user } = useAuth();
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const onFinish = async (values: { email: string; password: string }) => {
    setLoading(true);
    try {
      // If input doesn't contain @, treat it as username and append domain
      const email = values.email.includes('@') ? values.email : `${values.email}@kindergarten.com`;
      const { error } = await signIn(email, values.password);
      if (error) {
        message.error(error);
      } else {
        message.success('登录成功，正在跳转...');
      }
    } catch {
      message.error('登录失败，请检查网络连接');
    } finally {
      setLoading(false);
    }
  };

  // Redirect after successful login - with timeout fallback
  React.useEffect(() => {
    if (profile) {
      const target = ROLE_HOME[profile.role] || '/tracking';
      router.push(target);
    } else if (user && !profile) {
      // User logged in but profile not loaded yet - wait a bit then try to redirect
      const timer = setTimeout(() => {
        // If still no profile after 3s, redirect to tracking as fallback
        router.push('/tracking');
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [profile, user, router]);

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      background: 'linear-gradient(135deg, #f0f9eb 0%, #e6f7ff 100%)',
    }}>
      <Card
        style={{ width: 420, borderRadius: 12, boxShadow: '0 4px 24px rgba(0,0,0,0.08)' }}
        styles={{ body: { padding: '40px 32px' } }}
      >
        <Space orientation="vertical" size="small" style={{ width: '100%', textAlign: 'center', marginBottom: 32 }}>
          <div style={{
            width: 64, height: 64, borderRadius: 16,
            background: '#52c41a', display: 'flex', alignItems: 'center',
            justifyContent: 'center', margin: '0 auto 16px',
            fontSize: 32, color: '#fff',
          }}>
            🍎
          </div>
          <Title level={3} style={{ margin: 0, color: '#1a1a1a' }}>幼儿园餐饮管理系统</Title>
          <Text type="secondary">请使用用户名和密码登录</Text>
        </Space>

        <Form
          name="login"
          onFinish={onFinish}
          autoComplete="off"
          size="large"
        >
          <Form.Item
            name="email"
            rules={[
              { required: true, message: '请输入用户名' },
            ]}
          >
            <Input prefix={<UserOutlined />} placeholder="用户名" />
          </Form.Item>

          <Form.Item
            name="password"
            rules={[{ required: true, message: '请输入密码' }]}
          >
            <Input.Password prefix={<LockOutlined />} placeholder="密码" />
          </Form.Item>

          <Form.Item>
            <Button
              type="primary"
              htmlType="submit"
              loading={loading}
              block
              style={{ height: 44, borderRadius: 8, fontSize: 16 }}
            >
              登 录
            </Button>
          </Form.Item>
        </Form>

      </Card>
    </div>
  );
}
