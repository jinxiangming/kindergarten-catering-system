'use client';

import React, { useState, useEffect, useCallback } from 'react';
import {
  Card, Table, Tag, Button, Modal, Space, Tabs, Empty, message,
  Descriptions, Form, Input, Select, Timeline,
} from 'antd';
import {
  CheckCircleOutlined, CloseCircleOutlined, EyeOutlined,
} from '@ant-design/icons';
import { useAuth } from '@/contexts/AuthContext';
import { getBrowserClient } from '@/lib/supabase';
import {
  RECIPE_STATUS_LABELS, MEAL_TYPE_LABELS,
  type Recipe, type RecipeDetail, type ApprovalRecord, type MealType,
} from '@/types';
import dayjs from 'dayjs';

export default function PrincipalPage() {
  const { user } = useAuth();
  const supabase = getBrowserClient();
  const [activeTab, setActiveTab] = useState('pending');
  const [pendingRecipes, setPendingRecipes] = useState<Recipe[]>([]);
  const [allRecipes, setAllRecipes] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState(false);

  // Approve modal
  const [approveModalOpen, setApproveModalOpen] = useState(false);
  const [currentRecipe, setCurrentRecipe] = useState<Recipe | null>(null);
  const [recipeDetails, setRecipeDetails] = useState<RecipeDetail[]>([]);
  const [approvalRecords, setApprovalRecords] = useState<ApprovalRecord[]>([]);
  const [approveForm] = Form.useForm();

  // Detail modal
  const [detailModalOpen, setDetailModalOpen] = useState(false);
  const [detailRecipe, setDetailRecipe] = useState<Recipe | null>(null);
  const [detailDetails, setDetailDetails] = useState<RecipeDetail[]>([]);
  const [detailRecords, setDetailRecords] = useState<ApprovalRecord[]>([]);

  const fetchData = useCallback(async () => {
    setLoading(true);

    const { data: pending } = await supabase
      .from('recipes')
      .select('*, profiles:uploader_id(display_name, email)')
      .eq('status', 'pending_principal')
      .order('created_at', { ascending: false });
    setPendingRecipes((pending || []) as unknown as Recipe[]);

    const { data: all } = await supabase
      .from('recipes')
      .select('*, profiles:uploader_id(display_name, email)')
      .order('created_at', { ascending: false })
      .limit(100);
    setAllRecipes((all || []) as unknown as Recipe[]);

    setLoading(false);
  }, [supabase]);

  useEffect(() => { fetchData(); }, [fetchData]);

  const openApproveModal = async (recipe: Recipe) => {
    setCurrentRecipe(recipe);
    approveForm.resetFields();

    const { data: details } = await supabase
      .from('recipe_details')
      .select('*')
      .eq('recipe_id', recipe.id)
      .order('date')
      .order('meal_type');
    setRecipeDetails((details || []) as RecipeDetail[]);

    const { data: records } = await supabase
      .from('approval_records')
      .select('*, profiles:approver_id(display_name, email)')
      .eq('recipe_id', recipe.id)
      .order('created_at');
    setApprovalRecords((records || []) as unknown as ApprovalRecord[]);

    setApproveModalOpen(true);
  };

  const handleApprove = async (result: 'approved' | 'rejected') => {
    if (!currentRecipe || !user) return;
    const { comment, reject_target } = approveForm.getFieldsValue();

    if (result === 'rejected' && !comment) {
      message.warning('退回时必须填写原因');
      return;
    }

    setLoading(true);
    try {
      await supabase.from('approval_records').insert({
        recipe_id: currentRecipe.id,
        approver_id: user.id,
        step: 'principal',
        result,
        comment,
      });

      let newStatus: string;
      if (result === 'approved') {
        newStatus = 'effective';
      } else {
        const target = reject_target || 'kitchen';
        if (target === 'health_doctor') newStatus = 'rejected_kitchen';
        else if (target === 'kitchen') newStatus = 'rejected_kitchen';
        else newStatus = 'rejected_finance';
      }

      await supabase.from('recipes').update({
        status: newStatus,
        reject_reason: result === 'rejected' ? comment : null,
        reject_step: result === 'rejected' ? reject_target : null,
        updated_at: new Date().toISOString(),
      }).eq('id', currentRecipe.id);

      // Notify
      await supabase.from('notifications').insert({
        user_id: currentRecipe.uploader_id,
        type: result === 'approved' ? 'principal_approved' : 'principal_rejected',
        title: result === 'approved' ? '园长终审通过' : '园长退回',
        content: result === 'approved'
          ? `您提交的${currentRecipe.week_start_date}周食谱已生效`
          : `您提交的${currentRecipe.week_start_date}周食谱被园长退回，原因：${comment}`,
        related_id: currentRecipe.id,
      });

      message.success(result === 'approved' ? '已通过，食谱生效' : '已退回');
      setApproveModalOpen(false);
      fetchData();
    } catch (err) {
      message.error('操作失败');
    }
    setLoading(false);
  };

  const openDetailModal = async (recipe: Recipe) => {
    setDetailRecipe(recipe);
    const { data: details } = await supabase.from('recipe_details').select('*').eq('recipe_id', recipe.id).order('date');
    setDetailDetails((details || []) as RecipeDetail[]);
    const { data: records } = await supabase.from('approval_records').select('*, profiles:approver_id(display_name, email)').eq('recipe_id', recipe.id).order('created_at');
    setDetailRecords((records || []) as unknown as ApprovalRecord[]);
    setDetailModalOpen(true);
  };

  const pendingColumns = [
    {
      title: '周开始日期', dataIndex: 'week_start_date', key: 'week_start_date',
      render: (d: string) => dayjs(d).format('YYYY-MM-DD'),
    },
    {
      title: '上传者', key: 'uploader',
      render: (_: unknown, r: Recipe) => (r.profiles as { display_name: string })?.display_name || '-',
    },
    {
      title: '提交时间', dataIndex: 'created_at', key: 'created_at',
      render: (d: string) => dayjs(d).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: '操作', key: 'action',
      render: (_: unknown, r: Recipe) => (
        <Space>
          <Button size="small" icon={<EyeOutlined />} onClick={() => openDetailModal(r)}>查看</Button>
          <Button size="small" type="primary" onClick={() => openApproveModal(r)}>审核</Button>
        </Space>
      ),
    },
  ];

  const allRecipeColumns = [
    {
      title: '周开始日期', dataIndex: 'week_start_date', key: 'week_start_date',
      render: (d: string) => dayjs(d).format('YYYY-MM-DD'),
    },
    {
      title: '上传者', key: 'uploader',
      render: (_: unknown, r: Recipe) => (r.profiles as { display_name: string })?.display_name || '-',
    },
    {
      title: '状态', dataIndex: 'status', key: 'status',
      render: (s: string) => <Tag color={s.includes('reject') ? 'error' : s === 'effective' ? 'success' : 'processing'}>{RECIPE_STATUS_LABELS[s as keyof typeof RECIPE_STATUS_LABELS]}</Tag>,
    },
    {
      title: '提交时间', dataIndex: 'created_at', key: 'created_at',
      render: (d: string) => dayjs(d).format('YYYY-MM-DD HH:mm'),
    },
    {
      title: '操作', key: 'action',
      render: (_: unknown, r: Recipe) => <Button size="small" icon={<EyeOutlined />} onClick={() => openDetailModal(r)}>查看详情</Button>,
    },
  ];

  return (
    <div>
      <h2 style={{ marginBottom: 24 }}>最终审核</h2>
      <Tabs activeKey={activeTab} onChange={setActiveTab} items={[
        {
          key: 'pending',
          label: <span>待审核{pendingRecipes.length > 0 && <Tag color="red" style={{ marginLeft: 4 }}>{pendingRecipes.length}</Tag>}</span>,
          children: (
            <Card>
              <Table columns={pendingColumns} dataSource={pendingRecipes} rowKey="id" loading={loading}
                locale={{ emptyText: <Empty description="暂无待审核食谱" /> }} />
            </Card>
          ),
        },
        {
          key: 'all',
          label: '全流程记录',
          children: (
            <Card>
              <Table columns={allRecipeColumns} dataSource={allRecipes} rowKey="id" loading={loading} />
            </Card>
          ),
        },
      ]} />

      {/* Approve Modal */}
      <Modal
        title="最终审核"
        open={approveModalOpen}
        forceRender
        onCancel={() => setApproveModalOpen(false)}
        footer={null}
        width={900}
      >
        {currentRecipe && (
          <div>
            <Descriptions bordered size="small" column={2} style={{ marginBottom: 16 }}>
              <Descriptions.Item label="周开始日期">{dayjs(currentRecipe.week_start_date).format('YYYY-MM-DD')}</Descriptions.Item>
              <Descriptions.Item label="上传者">{(currentRecipe.profiles as { display_name: string })?.display_name}</Descriptions.Item>
            </Descriptions>

            <Card title="食谱明细" size="small" style={{ marginBottom: 16 }}>
              <Table
                columns={[
                  { title: '日期', dataIndex: 'date', key: 'date', render: (d: string) => dayjs(d).format('MM-DD') },
                  { title: '餐别', dataIndex: 'meal_type', key: 'meal_type', render: (t: MealType) => MEAL_TYPE_LABELS[t] },
                  { title: '菜品', dataIndex: 'dish_name', key: 'dish_name' },
                  { title: '食材与带量', dataIndex: 'ingredient', key: 'ingredient' },
                ]}
                dataSource={recipeDetails} rowKey="id" size="small" pagination={false}
              />
            </Card>

            <Card title="全流程审核记录" size="small" style={{ marginBottom: 16 }}>
              {approvalRecords.length > 0 ? (
                <Timeline items={approvalRecords.map(r => ({
                  color: r.result === 'approved' ? 'green' : 'red',
                  content: (
                    <div>
                      <strong>{r.step === 'kitchen' ? '厨房审核' : r.step === 'finance' ? '财务审核' : '园长审核'}</strong>
                      <Tag color={r.result === 'approved' ? 'success' : 'error'} style={{ marginLeft: 8 }}>
                        {r.result === 'approved' ? '通过' : '退回'}
                      </Tag>
                      {r.profiles && <div style={{ color: '#888' }}>审核人：{(r.profiles as { display_name: string }).display_name}</div>}
                      {r.comment && <div style={{ color: '#666' }}>意见：{r.comment}</div>}
                      <div style={{ color: '#aaa', fontSize: 12 }}>{dayjs(r.created_at).format('YYYY-MM-DD HH:mm')}</div>
                    </div>
                  ),
                }))} />
              ) : <Empty description="暂无审核记录" />}
            </Card>

            <Form form={approveForm}>
              <Form.Item name="comment" label="审核意见">
                <Input.TextArea rows={3} placeholder="退回时必须填写原因" />
              </Form.Item>
              <Form.Item name="reject_target" label="退回目标">
                <Select placeholder="选择退回目标" allowClear>
                  <Select.Option value="health_doctor">保健室</Select.Option>
                  <Select.Option value="kitchen">厨房</Select.Option>
                  <Select.Option value="finance">财务</Select.Option>
                </Select>
              </Form.Item>
            </Form>

            <Space>
              <Button type="primary" icon={<CheckCircleOutlined />} onClick={() => handleApprove('approved')} loading={loading}>
                通过，食谱生效
              </Button>
              <Button danger icon={<CloseCircleOutlined />} onClick={() => handleApprove('rejected')} loading={loading}>
                退回
              </Button>
            </Space>
          </div>
        )}
      </Modal>

      {/* Detail Modal */}
      <Modal title="食谱详情" open={detailModalOpen} onCancel={() => setDetailModalOpen(false)} footer={null} width={900}>
        {detailRecipe && (
          <div>
            <Descriptions bordered size="small" column={2} style={{ marginBottom: 16 }}>
              <Descriptions.Item label="周开始日期">{dayjs(detailRecipe.week_start_date).format('YYYY-MM-DD')}</Descriptions.Item>
              <Descriptions.Item label="状态"><Tag color={detailRecipe.status === 'effective' ? 'success' : 'processing'}>{RECIPE_STATUS_LABELS[detailRecipe.status as keyof typeof RECIPE_STATUS_LABELS]}</Tag></Descriptions.Item>
            </Descriptions>
            <Table
              columns={[
                { title: '日期', dataIndex: 'date', key: 'date', render: (d: string) => dayjs(d).format('MM-DD') },
                { title: '餐别', dataIndex: 'meal_type', key: 'meal_type', render: (t: MealType) => MEAL_TYPE_LABELS[t] },
                { title: '菜品', dataIndex: 'dish_name', key: 'dish_name' },
                { title: '食材与带量', dataIndex: 'ingredient', key: 'ingredient' },
              ]}
              dataSource={detailDetails} rowKey="id" size="small" pagination={false}
            />
            {detailRecords.length > 0 && (
              <Card title="审核记录" size="small" style={{ marginTop: 16 }}>
                <Timeline items={detailRecords.map(r => ({
                  color: r.result === 'approved' ? 'green' : 'red',
                  content: (
                    <div>
                      <strong>{r.step === 'kitchen' ? '厨房' : r.step === 'finance' ? '财务' : '园长'}</strong>
                      <Tag color={r.result === 'approved' ? 'success' : 'error'} style={{ marginLeft: 8 }}>
                        {r.result === 'approved' ? '通过' : '退回'}
                      </Tag>
                      {r.profiles && <span style={{ color: '#888' }}> - {(r.profiles as { display_name: string }).display_name}</span>}
                      {r.comment && <div style={{ color: '#666' }}>{r.comment}</div>}
                    </div>
                  ),
                }))} />
              </Card>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}
