'use client';

import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { useRouter } from 'next/navigation';
import type { UserRole } from '@/types';
import { Spin, Result, Button, Alert } from 'antd';

const ROLE_HOME: Record<UserRole, string> = {
  health_doctor: '/health-doctor',
  kitchen: '/kitchen',
  finance: '/finance',
  principal: '/principal',
};

export default function HomeContent() {
  const { user, profile, loading, configError } = useAuth();
  const router = useRouter();
  const [waitTimeout, setWaitTimeout] = useState(false);

  useEffect(() => {
    if (loading) return;
    if (!user) {
      router.push('/login');
      return;
    }
    if (profile) {
      router.push(ROLE_HOME[profile.role]);
    }
  }, [user, profile, loading, router]);

  // Timeout: if logged in but no profile after 5 seconds, show warning
  useEffect(() => {
    if (!user || profile) return;
    const t = setTimeout(() => setWaitTimeout(true), 5000);
    return () => clearTimeout(t);
  }, [user, profile]);

  if (configError) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', padding: 24 }}>
        <Result
          status="error"
          title="Supabase 未配置"
          subTitle="请先在项目根目录创建 .env.local 文件，填入 Supabase 连接信息后重启项目。"
          extra={[
            <Button type="primary" key="retry" onClick={() => window.location.reload()}>
              重试
            </Button>,
          ]}
        >
          <div style={{ textAlign: 'left', maxWidth: 500, margin: '0 auto', fontSize: 13, color: '#666' }}>
            <p>需要在 .env.local 中配置以下环境变量：</p>
            <pre style={{ background: '#f5f5f5', padding: 12, borderRadius: 6, fontSize: 12 }}>
{`NEXT_PUBLIC_SUPABASE_URL=https://xxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJ...
COZE_SUPABASE_SERVICE_ROLE_KEY=eyJ...`}
            </pre>
          </div>
        </Result>
      </div>
    );
  }

  // User logged in but no profile found - show helpful message
  if (!loading && user && !profile) {
    return (
      <div style={{ minHeight: '100vh', display: 'flex', justifyContent: 'center', alignItems: 'center', padding: 24 }}>
        <Result
          status="warning"
          title="用户角色信息缺失"
          subTitle="您的账号在 profiles 表中没有对应记录，请联系管理员在 Supabase 后台的 profiles 表中添加您的用户信息。"
          extra={[
            <Button type="primary" key="retry" onClick={() => window.location.reload()}>
              重新加载
            </Button>,
            <Button key="logout" onClick={() => { /* force logout by clearing storage */ localStorage.clear(); window.location.href = '/login'; }}>
              退出登录
            </Button>,
          ]}
        >
          <div style={{ textAlign: 'left', maxWidth: 500, margin: '0 auto', fontSize: 13, color: '#666' }}>
            <p>需要在 Supabase → Table Editor → profiles 表中添加：</p>
            <pre style={{ background: '#f5f5f5', padding: 12, borderRadius: 6, fontSize: 12 }}>
{`id: ${user.id}
name: 您的姓名
role: principal / health_doctor / kitchen / finance
is_active: true`}
            </pre>
          </div>
        </Result>
      </div>
    );
  }

  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
      <Spin size="large" />
      {waitTimeout && (
        <Alert
          style={{ marginTop: 24, maxWidth: 400 }}
          title="加载时间较长，请检查网络连接和 Supabase 配置"
          type="info"
          showIcon
        />
      )}
    </div>
  );
}
